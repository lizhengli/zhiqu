package com.lianyi.exception;

public class NewsException extends Exception {
    public NewsException(String message){
        super(message);
    }
}
