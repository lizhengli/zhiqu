package com.lianyi.exception;

/**
 * Created by Lenovo on 2017/6/19.
 */
public class UserException extends Exception{
    public UserException(String s){
        super(s);
    }
}
