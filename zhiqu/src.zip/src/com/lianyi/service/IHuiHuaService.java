package com.lianyi.service;

import com.lianyi.bean.HuiHuaBean;

import java.util.List;

/**
 * Created by Lenovo on 2017/7/17.
 */
public interface IHuiHuaService {
    //新增
    public void add(HuiHuaBean huiHua);
    //全部
    public List<HuiHuaBean> getAll();
    //返回指定一条
    public HuiHuaBean getById(Integer id);
    //修改
    public void update(Integer id, String name);
    //删除
    public void delete(Integer id);
    //条件删除
    public void delete(String condition);

    public List<HuiHuaBean> findAll();

    public HuiHuaBean findById(Integer id);

    public void save(HuiHuaBean huiHua);

    public void deleteByCondition(String s);
}
