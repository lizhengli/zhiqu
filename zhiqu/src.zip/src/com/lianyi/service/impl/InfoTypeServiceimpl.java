package com.lianyi.service.impl;

import com.lianyi.bean.FabuRen;
import com.lianyi.bean.InfoType;
import com.lianyi.bean.NewsBean;
import com.lianyi.bean.info;
import com.lianyi.dao.IinfoTypeDao;
import com.lianyi.dao.impl.IinfoTypeDaoimpl;

import java.util.List;

/**
 * Created by dell on 2017/7/16.
 */
public class InfoTypeServiceimpl implements IinfoTypeService {
    IinfoTypeDao iinfoTypeDao = new IinfoTypeDaoimpl();
    @Override
    public List<InfoType> ftype() {
        return iinfoTypeDao.ftype();
    }

    @Override
    public List<InfoType> stype(int pid) {
        return iinfoTypeDao.stype(pid);
    }

    @Override
    public List<info> infoftype(int id) {
        return iinfoTypeDao.infoftype(id);
    }

    @Override
    public List<info> infostype(int id) {
        return iinfoTypeDao.infostype(id);
    }

    @Override
    public FabuRen getstypeinfo(int uid, String title) {
        return  iinfoTypeDao.getstypeinfo(uid,title);
    }


    @Override
    public FabuRen getftypeinfo(int uid, String title) {
        return iinfoTypeDao.getstypeinfo(uid,title);
    }

    @Override
    public List<info> souinfo(String n) {
        return iinfoTypeDao.souinfo(n);
    }

    @Override
    public List<NewsBean> sounews(String n) {
        return iinfoTypeDao.sounews(n);
    }
}
