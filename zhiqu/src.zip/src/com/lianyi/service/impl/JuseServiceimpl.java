package com.lianyi.service.impl;

import com.lianyi.bean.JueSe;
import com.lianyi.bean.Juse;
import com.lianyi.bean.Rizhi;
import com.lianyi.dao.IJuseDao;
import com.lianyi.dao.impl.JuseDaoimpl;
import com.lianyi.exception.NewsException;
import com.lianyi.service.IjuSeService;

import java.sql.SQLException;
import java.util.List;

/**
 * Created by dell on 2017/7/7.
 */
public class JuseServiceimpl implements IjuSeService {
    IJuseDao iJuseDao = new JuseDaoimpl();
    @Override
    public List<JueSe> getAll() {
        return iJuseDao.getAll();
    }

    @Override
    public void addJuse(JueSe jueSe) throws NewsException {
        iJuseDao.addJuse(jueSe);
    }

    @Override
    public void delete(int id) throws NewsException {
        iJuseDao.delete(id);
    }

    @Override
    public JueSe select(int id) throws NewsException {
        try {
            return  iJuseDao.select(id);
        } catch (SQLException e) {
            throw  new RuntimeException(e);
        }
    }

    @Override
    public void update(JueSe jueSe) throws NewsException {
        iJuseDao.update(jueSe);
    }

    @Override
    public List<Rizhi> getRizhi() {
        return iJuseDao.getRizhi();
    }
}
