package com.lianyi.service.impl;

import com.lianyi.Factory.BeanFactory;
import com.lianyi.bean.HuiHuaBean;
import com.lianyi.dao.IHuiHuaDao;
import com.lianyi.dao.impl.HuiHuaDaoImpl;
import com.lianyi.service.IHuiHuaService;

import java.util.List;

/**
 * Created by Lenovo on 2017/7/17.
 */
public class HuiHuaServiceImpl implements IHuiHuaService {
    IHuiHuaDao iHuiHuaDao = new HuiHuaDaoImpl();

    public HuiHuaServiceImpl() throws IllegalAccessException, InstantiationException, ClassNotFoundException {
    }
    @Override
    public void save(HuiHuaBean model) {
        iHuiHuaDao.add(model);
    }


    public void save(List<HuiHuaBean> models) {

    }


    public void deleteById(Integer id) {
        iHuiHuaDao.delete(id);
    }


    public void deleteByIds(String ids) {

    }
    public void deleteByCondition(String condition){
        iHuiHuaDao.delete(condition);
    }

    /*@Override
    public void update(HuiHuaBean model) {

    }*/

    @Override
    public void add(HuiHuaBean huiHua) {

    }

    @Override
    public List<HuiHuaBean> getAll() {
        return null;
    }

    @Override
    public HuiHuaBean getById(Integer id) {
        return null;
    }

    public void update(Integer id, String name) {
        iHuiHuaDao.update(id,name);
    }

    @Override
    public void delete(Integer id) {

    }

    @Override
    public void delete(String condition) {

    }

    @Override
    public HuiHuaBean findById(Integer id) {
        return iHuiHuaDao.getById(id);
    }


    public HuiHuaBean findBy(String property, Object value) {
        return null;
    }


    public List<HuiHuaBean> findByIds(String ids) {
        return null;
    }


    public List<HuiHuaBean> findByCondition(String condition) {
        return null;
    }

    @Override
    public List<HuiHuaBean> findAll() {
        return iHuiHuaDao.getAll();
    }
}
