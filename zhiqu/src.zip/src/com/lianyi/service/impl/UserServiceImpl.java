package com.lianyi.service.impl;

import com.lianyi.bean.User;
import com.lianyi.dao.IUserDao;
import com.lianyi.dao.impl.UserDaoImpl;
import com.lianyi.service.IUserService;
import com.lianyi.exception.UserException;

import java.util.List;

/**
 * Created by Lenovo on 2017/6/16.
 */
public class UserServiceImpl implements IUserService{
    IUserDao iUserDao = new UserDaoImpl();
    @Override
    public List<User> getUsers() {
        return iUserDao.getAllUsers();
    }

    @Override
    public void addUser(String name) throws UserException{
        int re = iUserDao.addUser(name);
        if(re!=0){
           throw  new UserException("插入数据异常"+name);
        }
    }

    @Override
    public void updateUser(int id, String name) {
        iUserDao.updateUser(id,name);
    }

    @Override
    public User selectUser(int id) throws UserException{
        User user = iUserDao.selectUser(id);
        if(user == null) {
            throw new UserException("未查到数据" + id);
        }
        else {
            return user;
        }
    }

    @Override
    public void delectUser(String name) throws UserException{
        int re = iUserDao.delectUser(name);
        if(re!=0){
            throw  new UserException("插入数据异常"+name);
        }
    }
}
