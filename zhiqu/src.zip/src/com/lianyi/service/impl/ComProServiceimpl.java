package com.lianyi.service.impl;

import com.lianyi.bean.Gsxx;
import com.lianyi.dao.impl.CompanyProductDaoimpl;
import com.lianyi.dao.impl.ICompanyProductDao;

import java.util.List;

/**
 * Created by dell on 2017/7/17.
 */
public class ComProServiceimpl implements IComproService {
    ICompanyProductDao iCompanyProductDao = new CompanyProductDaoimpl();
    @Override
    public List<Gsxx> getgongsi() {
        return iCompanyProductDao.getgongsi();
    }

    @Override
    public Gsxx gscontent(int id) {
        return iCompanyProductDao.gscontent(id);
    }
}
