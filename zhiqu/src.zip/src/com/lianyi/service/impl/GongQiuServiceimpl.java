package com.lianyi.service.impl;

import com.lianyi.bean.info;
import com.lianyi.dao.impl.GongQiuDaoimpl;
import com.lianyi.dao.impl.IGongQiuDao;
import com.lianyi.service.IGongQiuServie;

import java.util.List;

/**
 * Created by dell on 2017/7/17.
 */
public class GongQiuServiceimpl implements IGongQiuServie {
    IGongQiuDao iGongQiuDao = new GongQiuDaoimpl();
    @Override
    public List<info> getAll() {
        return iGongQiuDao.getAll();
    }

    @Override
    public void shenhe(info info) {
        iGongQiuDao.shenhe(info);
    }

    @Override
    public void delete(info info) {
        iGongQiuDao.delete(info);
    }

    @Override
    public void gyshenhe(info info) {
        iGongQiuDao.gyshenhe(info);
    }
}
