package com.lianyi.service.impl;

import com.lianyi.bean.FabuRen;
import com.lianyi.bean.InfoType;
import com.lianyi.bean.NewsBean;
import com.lianyi.bean.info;

import java.util.List;

/**
 * Created by dell on 2017/7/16.
 */
public interface IinfoTypeService {
    public List<InfoType> ftype();
    public List<InfoType> stype(int pid);
    public List<info> infoftype(int id);
    public List<info> infostype(int id);
    public FabuRen getstypeinfo(int uid, String title);
    public FabuRen getftypeinfo(int uid,String title);
    public List<info> souinfo(String n);
    public List<NewsBean> sounews(String n);
}
