package com.lianyi.service.impl;

import com.lianyi.Factory.BeanFactory;
import com.lianyi.bean.Quanxian;
import com.lianyi.dao.ZtreeQuanxian;
import com.lianyi.dao.impl.ZtreeQuandaoimpl;
import com.lianyi.service.IZtreeService;

import java.util.List;

/**
 * Created by dell on 2017/7/8.
 */
public class ZtreeServiceimpl implements IZtreeService{
   ZtreeQuanxian ztreeQuanxian = new ZtreeQuandaoimpl();
    public List<Quanxian> findAll() {
        return ztreeQuanxian.fingAll();
    }
}
