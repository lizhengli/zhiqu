package com.lianyi.service.impl;


import MyException.AdminUserException;
import MyException.AdminUserPasswordException;
import com.lianyi.bean.AdminUser;
import com.lianyi.bean.AdminUser2;
import com.lianyi.bean.ZhiQuUser;
import com.lianyi.dao.IAdminUserDao;
import com.lianyi.dao.impl.AdminUserDaoimpl;
import com.lianyi.service.IAdminUserService;

/**
 * Created by dell on 2017/6/28.
 */
public class AdminUserServiceimpl implements IAdminUserService {
    IAdminUserDao iAdminUserDao = new AdminUserDaoimpl();

    @Override
    public AdminUser2 LoginCheck2(AdminUser2 adminUser) throws AdminUserException, AdminUserPasswordException {
        AdminUser2 adminUser2 = iAdminUserDao.getAdminUserByusrname(adminUser.getUsername());
        if (adminUser2==null){
            throw new AdminUserException("用户名不对");
        }else{
            if (!adminUser2.getPassword().equals(adminUser.getPassword())){
                throw new AdminUserPasswordException("密码错误");
            }
        }
        return adminUser2;

    }

    @Override
    public AdminUser LoginCheck(AdminUser adminUser) throws AdminUserException, AdminUserPasswordException {
       AdminUser adminuser1 = iAdminUserDao.getZhiquUserByusrname(adminUser.getName());
       if(adminuser1==null){
            //用户名不对
           throw new AdminUserException("用户名不对");
       }else{
           if(adminuser1.getPassword().equals(adminUser.getPassword())){
               //登录成功
           }else{
               //密码错误
               throw new AdminUserPasswordException("密码错误");
           }
       }
        return adminuser1;
    }
}
