package com.lianyi.service.impl;

import com.lianyi.Factory.BeanFactory;
import com.lianyi.bean.Type;
import com.lianyi.dao.ITypeDao;
import com.lianyi.dao.ZtreeQuanxian;
import com.lianyi.service.ITypeService;

import java.util.List;

/**
 * Created by Lenovo on 2017/6/26.
 */
public class TypeServiceImpl implements ITypeService{
    ITypeDao iTypeDao = BeanFactory.getInstance("typeDao",ITypeDao.class);

    public TypeServiceImpl() throws IllegalAccessException, InstantiationException, ClassNotFoundException {
    }

    @Override
    public List<Type> getAll() {
        return iTypeDao.getAll();
    }

    @Override
    public List<Type> getParents() {
        return null;
    }

    @Override
    public void addType(Type type) {
        iTypeDao.addType(type.getTitle(),type.getDescription(),type.getPid());
    }

    @Override
    public void deleteType(int id) {
        iTypeDao.deleteType(id);
    }

    @Override
    public void update(Type type) {
        iTypeDao.update(type.getId(),type.getTitle(),type.getDescription(),type.getPid());
    }

    @Override
    public Type getTypeById(int id) {
        return iTypeDao.getTypeById(id);
    }
}
