package com.lianyi.service.impl;

import com.lianyi.bean.Jsqx;
import com.lianyi.bean.Quanxian;

import com.lianyi.dao.IQuanxianDao;
import com.lianyi.dao.impl.QuanxianDaoimpl;
import com.lianyi.exception.NewsException;
import com.lianyi.service.IQuanxianService;

import java.util.List;

/**
 * Created by dell on 2017/7/6.
 */
public class QuanxianServiceimpl implements IQuanxianService {
    IQuanxianDao iQuanxianDao = new QuanxianDaoimpl();
    @Override
    public List<Quanxian> getQuanxian() {

        return iQuanxianDao.getQuanxian();
    }

    @Override
    public void addQuan(String title,String q_type, String url,int status,int pid) throws  NewsException {
        try {
            iQuanxianDao.addQuan(title,q_type,url,status,pid);
        } catch (NewsException e) {
            e.printStackTrace();
        }

    }

    @Override
    public void deleteQuan(int id) throws NewsException {
        iQuanxianDao.deleteQuan(id);
    }

    @Override
    public Quanxian select(int id) throws NewsException {
        return iQuanxianDao.select(id);
    }

    @Override
    public void uqx(Quanxian quanxian) throws NewsException{
        iQuanxianDao.uqx(quanxian);
    }

    @Override
    public void juseqx(Jsqx jsqx) throws NewsException {
        iQuanxianDao.juseqx(jsqx);
    }

    @Override
    public List<Jsqx> getPerid(int id) {
        return iQuanxianDao.getPerid(id);
    }

    @Override
    public void gouxuan(int id) {
        iQuanxianDao.gouxuan(id);
    }
}
