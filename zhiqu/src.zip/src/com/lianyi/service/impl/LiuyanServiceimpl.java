package com.lianyi.service.impl;

import com.lianyi.bean.LiuYan;
import com.lianyi.bean.info;
import com.lianyi.dao.IliuyanDao;
import com.lianyi.dao.impl.LiuyanDaoimpl;
import com.lianyi.service.IliuYanService;

import java.util.List;

/**
 * Created by dell on 2017/7/14.
 */
public class LiuyanServiceimpl implements IliuYanService {
    IliuyanDao iliuyanDao = new LiuyanDaoimpl();
    @Override
    public void addLiuyan(LiuYan liuYan) {
        iliuyanDao.addLiuyan(liuYan);
    }

    @Override
    public List<LiuYan> xiaoxi(String fbr) {
        return iliuyanDao.xiaoxi(fbr);
    }
    public LiuYan liuyan(int id){
        return iliuyanDao.liuyan(id);
    }

    @Override
    public List<LiuYan> getAll() {
        return iliuyanDao.getAll();
    }

    @Override
    public void shenhe(LiuYan liuYan) {
        iliuyanDao.shenhe(liuYan);
    }

    @Override
    public void delete(int id) {
        iliuyanDao.delete(id);
    }

    @Override
    public void read(int id) {
        iliuyanDao.read(id);
    }

    @Override
    public info infocontent(String title) {
       return  iliuyanDao.infocontent(title);
    }
}
