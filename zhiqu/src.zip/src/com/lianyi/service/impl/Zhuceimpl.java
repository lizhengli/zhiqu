package com.lianyi.service.impl;

import com.lianyi.bean.AdminUser;
import com.lianyi.bean.Gsinfo;
import com.lianyi.bean.ZhiQuUser;
import com.lianyi.dao.ZhuCeDao;
import com.lianyi.dao.impl.ZhuCeDaoimpl;
import com.lianyi.service.IZhuCeService;

import java.util.List;
import java.util.Map;

/**
 * Created by dell on 2017/6/30.
 */
public class Zhuceimpl  implements IZhuCeService {
    ZhuCeDao zhuCeDao = new ZhuCeDaoimpl();
    @Override
    public List getSheng() {
        return zhuCeDao.getSheng();
    }

    @Override
    public Map getCity(String code) {
        return zhuCeDao.getCity(code);
    }
    public void userZhuce(ZhiQuUser zhiQuUser){

        zhuCeDao.userZhuce(zhiQuUser);
    }
    public void gsZhuce(Gsinfo gsinfo){
        zhuCeDao.gsZhuce(gsinfo);
    }

    @Override
    public void addUser(AdminUser adminUser) {
         zhuCeDao.addUser(adminUser);

    }
}
