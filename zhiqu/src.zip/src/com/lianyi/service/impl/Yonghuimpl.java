package com.lianyi.service.impl;

import com.lianyi.bean.AdminUser2;
import com.lianyi.bean.Jsyh;
import com.lianyi.bean.JueSe;
import com.lianyi.dao.IYonghuDao;
import com.lianyi.dao.impl.YonghuDaoimpl;
import com.lianyi.exception.NewsException;
import com.lianyi.service.IYonghuService;

import java.util.List;

/**
 * Created by dell on 2017/7/3.
 */
public class Yonghuimpl implements IYonghuService {
    IYonghuDao iYonghuDao = new YonghuDaoimpl();

    @Override
    public void addAdmin(AdminUser2 juse) throws NewsException {
        iYonghuDao.addAdmin(juse);
    }

    @Override
    public List<AdminUser2> getAll() {
        return iYonghuDao.getAll();
    }

    @Override
    public void delete(int id) {
        iYonghuDao.delete(id);
    }

    @Override
    public AdminUser2 getById(int id) {
        return iYonghuDao.getById(id);
    }

    @Override
    public void update(AdminUser2 adminUser2) {
        iYonghuDao.update(adminUser2);
    }

    @Override
    public void juse(int uid, int rid) throws NewsException {
        iYonghuDao.juse(uid,rid);
    }

    @Override
    public List<JueSe> getJuse() {
        return iYonghuDao.getJuse();
    }

    @Override
    public void deleteJuse(int id) throws NewsException{
        iYonghuDao.deleteJuse(id);
    }

    @Override
    public Jsyh getJuseById(int id) {
        return iYonghuDao.getJuseById(id);
    }

    @Override
    public void shanchu(int id) {
        iYonghuDao.shanchu(id);
    }
}
