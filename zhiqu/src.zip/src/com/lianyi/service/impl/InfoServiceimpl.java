package com.lianyi.service.impl;

import com.lianyi.bean.*;
import com.lianyi.bean.Number;
import com.lianyi.dao.IinfoDao;
import com.lianyi.dao.impl.InfoDaoimpl;
import com.lianyi.exception.NewsException;
import com.lianyi.service.IinfoService;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by dell on 2017/7/5.
 */
public class InfoServiceimpl implements IinfoService {
    IinfoDao iinfoDao = new InfoDaoimpl();
    List<info> list = new ArrayList<info>();
    @Override
    public List<info> qiugou() {
        return iinfoDao.qiugou();
    }

    @Override
    public List<info> gongying() {
        return iinfoDao.gongying();
    }

    @Override
    public FabuRen getNew1(int id,String title) {
        return iinfoDao.getNew1(id,title);
    }

    @Override
    public FabuRen getNew2(int id,String title) {
        return iinfoDao.getNew2(id,title);
    }

    @Override
    public void addinfo1(info ifo) throws  NewsException {
        try {
            iinfoDao.addinfo(ifo);
        } catch (NewsException e) {
            e.printStackTrace();
        }

    }

    @Override
    public void addgy(info ifo) throws NewsException  {
        try {
            iinfoDao.addgy(ifo);
        } catch (NewsException e) {
            e.printStackTrace();
        }
    }

    @Override
    public List<info> gerenQiugou(int id) {
        return iinfoDao.gerenQiugou(id);
    }

    @Override
    public Userinfo getInfo(int id) {
        return iinfoDao.getInfo(id);
    }

    @Override
    public List<info> winfo(int id,int page,int shownumber) {
        return iinfoDao.winfo(id,page,shownumber);
    }

    @Override
    public List<info> winfo2(int id) {
        return iinfoDao.winfo2(id);
    }

    @Override
    public void deleteqg(int id) {
        iinfoDao.deleteqg(id);
    }

    @Override
    public void deletegy(int id) {
        iinfoDao.deletegy(id);
    }

    @Override
    public info allinfoftype(int id) {
        return iinfoDao.allinfoftype(id);
    }

    @Override
    public info allinfostype(int id) {
        return iinfoDao.allinfostype(id);
    }

    @Override
    public void addllinfo(info ifo) {
        iinfoDao.addllinfo(ifo);
    }

    @Override
    public List<info> getByPageNumber(int page,int shownumber,String ku) {
        return iinfoDao.getByPageNumber(page,shownumber,ku);
    }

    @Override
    public int getCount(String ku) {
        return iinfoDao.getCount(ku);
    }


}
