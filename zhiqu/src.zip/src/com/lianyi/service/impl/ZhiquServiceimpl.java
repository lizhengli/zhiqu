package com.lianyi.service.impl;

import com.lianyi.bean.Gongying;
import com.lianyi.dao.IzhiquDao;
import com.lianyi.dao.impl.ZhiquDaoimpl;
import com.lianyi.service.IzhiquService;

import java.util.List;
import java.util.Map;

/**
 * Created by dell on 2017/7/4.
 */
public class ZhiquServiceimpl implements IzhiquService {
    IzhiquDao izhiquDao = new ZhiquDaoimpl();

    @Override
    public List<Gongying> xianshi(int id) {
       return  izhiquDao.xianshi(id);
    }

    @Override
    public List<Gongying> gongying(int id) {
        return izhiquDao.gongying(id);
    }
}
