package com.lianyi.service.impl;



import com.lianyi.Factory.BeanFactory;
import com.lianyi.bean.NewsBean;
import com.lianyi.bean.NewsTypeBean;
import com.lianyi.dao.INewsDao;
import com.lianyi.dao.impl.NewsDaoImpl;
import com.lianyi.exception.NewsException;
import com.lianyi.service.INewsService;

import java.util.List;

public class NewsServiceImpl implements INewsService {
    INewsDao iNewsDao = new NewsDaoImpl();

    @Override
    //所有新闻
    public List<NewsBean> getNewsAll() {
        return iNewsDao.getNewsAll();
    }

    @Override
    //新闻类型
    public List<NewsTypeBean> getNewsTypeALL() {
        return iNewsDao.getNewsTypeALL();
    }

    @Override
    //新增新闻
    public void addNew(NewsBean newsBean) throws NewsException {
        iNewsDao.addNew(newsBean);
    }

    @Override
    //返回一条新闻
    public NewsBean getNew(int id) throws NewsException {
        return  iNewsDao.getNew(id);
    }

    @Override
    //删除新闻
    public void deleteNew(int id) throws NewsException {
        iNewsDao.deleteNew(id);
    }

    @Override
    public void updateNew(int id, NewsBean newsBean) throws NewsException {
        iNewsDao.updateNew(id,newsBean);
    }
}
