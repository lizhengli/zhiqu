package com.lianyi.service.impl;

import com.lianyi.bean.GuoLv;
import com.lianyi.bean.Rizhi;
import com.lianyi.dao.IGuolvDao;
import com.lianyi.dao.impl.GuolvDaoimpl;
import com.lianyi.service.IGuolvService;

import java.util.List;

/**
 * Created by dell on 2017/7/11.
 */
public class GuolvServliceimpl implements IGuolvService {
    IGuolvDao iGuolvDao = new GuolvDaoimpl();
    @Override
    public GuoLv roleid(int id) {
        return  iGuolvDao.roleid(id);
    }

    @Override
    public List<GuoLv> getUrl(int id) {
        return iGuolvDao.getUrl(id);
    }

    @Override
    public void addRizhi(Rizhi rizhi) {
        iGuolvDao.rzjl(rizhi);
    }
}
