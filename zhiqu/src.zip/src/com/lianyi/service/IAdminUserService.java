package com.lianyi.service;


import MyException.AdminUserException;
import MyException.AdminUserPasswordException;
import com.lianyi.bean.AdminUser;
import com.lianyi.bean.AdminUser2;

/**
 * Created by dell on 2017/6/28.
 */
public interface IAdminUserService {
    public AdminUser2 LoginCheck2(AdminUser2 adminUser2) throws AdminUserException,AdminUserPasswordException;
    public AdminUser LoginCheck(AdminUser adminUser) throws AdminUserException, AdminUserPasswordException;
}
