package com.lianyi.service;

import com.lianyi.bean.Rizhi;
import com.lianyi.bean.User;
import com.lianyi.exception.UserException;

import java.util.List;

/**
 * Created by Lenovo on 2017/6/16.
 */
public interface IUserService {
    public List<User> getUsers();
    public void addUser(String name) throws UserException;
    public void updateUser(int id, String name);
    public User selectUser(int id) throws UserException;
    public void delectUser(String name) throws UserException;
}
