package com.lianyi.service;

import com.lianyi.bean.Gongying;

import java.util.List;
import java.util.Map;

/**
 * Created by dell on 2017/7/4.
 */
public interface IzhiquService {
    public List<Gongying> xianshi(int id);
    public List<Gongying> gongying(int id);
}
