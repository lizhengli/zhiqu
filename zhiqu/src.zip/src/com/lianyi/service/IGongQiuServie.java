package com.lianyi.service;

import com.lianyi.bean.info;

import java.util.List;

/**
 * Created by dell on 2017/7/17.
 */
public interface IGongQiuServie {
    public List<info> getAll();
    public void shenhe(info info);
    public void delete(info info);
    public void gyshenhe(info info);
}
