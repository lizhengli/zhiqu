package com.lianyi.service;

import com.lianyi.bean.Type;

import java.util.List;

/**
 * Created by Lenovo on 2017/6/26.
 */
public interface ITypeService {
    /**
     * 获取所有数据类型
     * */
    public List<Type> getAll();


    /**
     * 获取第一级数据
     * */
    public List<Type> getParents();


    /**
     * 增加顶级类型
     * */
    public void addType(Type type);


    /**
     * 删除数据
     * */
    public void deleteType(int id);


    /**
     *修改数据
     **/
    public void update(Type type);


    /**
     *同过ID查询数据
     * */
    public Type getTypeById(int id);
}
