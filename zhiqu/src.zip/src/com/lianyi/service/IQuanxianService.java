package com.lianyi.service;

import com.lianyi.bean.Jsqx;
import com.lianyi.bean.Quanxian;
import com.lianyi.exception.NewsException;

import java.util.List;

/**
 * Created by dell on 2017/7/6.
 */
public interface IQuanxianService {
    public List<Quanxian> getQuanxian();
    public void addQuan(String title,String q_type,String url,int status,int pid) throws NewsException;
    public void deleteQuan(int id) throws NewsException;
    public Quanxian select(int id) throws NewsException;
    public void uqx(Quanxian quanxian)  throws NewsException;
    public void juseqx(Jsqx jsqx) throws NewsException;
    public List<Jsqx> getPerid(int id);
    public void gouxuan(int id);
}
