package com.lianyi.service;


import com.lianyi.bean.NewsBean;
import com.lianyi.bean.NewsTypeBean;
import com.lianyi.exception.NewsException;

import java.util.List;

public interface INewsService {
    //所有新闻
    public List<NewsBean> getNewsAll();
    //新闻类型
    public List<NewsTypeBean> getNewsTypeALL();
    //新增新闻
    public void addNew(NewsBean newsBean) throws NewsException;
    //返回一条新闻
    public NewsBean getNew(int id) throws NewsException;
    //删除新闻
    public void deleteNew(int id) throws NewsException;
    //修改新闻
    public void updateNew(int id, NewsBean newsBean) throws NewsException;
}
