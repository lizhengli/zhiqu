package com.lianyi.service;

import com.lianyi.bean.Quanxian;

import java.util.List;

/**
 * Created by dell on 2017/7/8.
 */
public interface IZtreeService {
    public List<Quanxian> findAll();
}
