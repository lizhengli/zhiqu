package com.lianyi.Factory;

import java.util.ResourceBundle;

/**
 * Created by Lenovo on 2017/6/22.
 */
public class BeanFactory {
    private static ResourceBundle bundle;
    static {
        bundle = ResourceBundle.getBundle("instance");
    }
    public static <T> T getInstance(String key, Class<T> tClass) throws ClassNotFoundException, IllegalAccessException, InstantiationException {
        try{
            String className = bundle.getString(key);
            return (T)Class.forName(className).newInstance();
        }catch (Exception e){
            throw  new RuntimeException(e);
        }
    }


}
