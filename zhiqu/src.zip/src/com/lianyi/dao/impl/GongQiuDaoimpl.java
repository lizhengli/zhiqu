package com.lianyi.dao.impl;

import com.lianyi.bean.info;
import com.lianyi.utils.JdbcUtils;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by dell on 2017/7/17.
 */
public class GongQiuDaoimpl implements IGongQiuDao {
    QueryRunner queryRunner = JdbcUtils.getQuerrRunner();
    List<info> list = new ArrayList<>();
    @Override
    public List<info> getAll() {
        String sql = "select * from llinfo";
        try {
            list = queryRunner.query(sql,new BeanListHandler<info>(info.class));
            return list;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void shenhe(info info){
        int gqid = info.getGqid();
        String sql = "update llinfo set status=? where id=?";
        try {
            queryRunner.update(sql,info.getStatus(),info.getId());
            if (gqid==1){
                qgshenhe(info);
            }else if (gqid==2){
                gyshenhe(info);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public void qgshenhe(info info){
        String sql = "update qiugou set status=? where title=? and uid=?";
        try {
            queryRunner.update(sql,info.getStatus(),info.getTitle(),info.getUid());
        } catch (SQLException e) {
            throw  new RuntimeException(e);
        }
    }
    public void gyshenhe(info info){
        String sql = "update gongying set status=? where title=? and uid=?";
        try {
            queryRunner.update(sql,info.getStatus(),info.getTitle(),info.getUid());
        } catch (SQLException e) {
            throw  new RuntimeException(e);
        }
    }
    public void delete(info ifo){
        String sql = "delete from llinfo where id=?";
        int gqid = ifo.getGqid();
        try {
            queryRunner.update(sql,ifo.getId());
            if (gqid==1){
                deleteqg(ifo);
            }else if (gqid==2){
                deletegy(ifo);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

    }
    public void deleteqg(info ifo){
        String sql ="delete from qiugou where title=? and uid=?";
        try {
            queryRunner.update(sql,ifo.getTitle(),ifo.getUid());
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    public void deletegy(info ifo){
        String sql ="delete from gongying where title=? and uid=?";
        try {
            queryRunner.update(sql,ifo.getTitle(),ifo.getUid());
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}
