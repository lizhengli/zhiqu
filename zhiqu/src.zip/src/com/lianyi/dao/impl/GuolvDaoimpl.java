package com.lianyi.dao.impl;

import com.lianyi.bean.GuoLv;
import com.lianyi.bean.Rizhi;
import com.lianyi.dao.IGuolvDao;
import com.lianyi.utils.JdbcUtils;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import java.sql.SQLException;
import java.util.List;

/**
 * Created by dell on 2017/7/11.
 */
public class GuolvDaoimpl implements IGuolvDao {
    QueryRunner queryRunner = JdbcUtils.getQuerrRunner();
    @Override
    public GuoLv roleid(int id) {
        String sql = "select roleid from yhjs  where userid=?";
        try {
           return  queryRunner.query(sql,new BeanHandler<GuoLv>(GuoLv.class),id);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public List<GuoLv> getUrl(int id) {
        String sql = "select quanxian.url from jsqx left join quanxian on jsqx.perid = quanxian.id LEFT  join juse on jsqx.roleid = juse.id where juse.id=?";
        try {
            return queryRunner.query(sql,new BeanListHandler<GuoLv>(GuoLv.class),id);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void rzjl(Rizhi rizhi) {
        String sql = "insert into rzjl(`caozuo`,`user`,`ctime`,`url`,`qtype`,`uip`,`biaozhi`) values(?,?,?,?,?,?,?)";
        try {
            queryRunner.update(sql,rizhi.getCaozuo(),rizhi.getUser(),rizhi.getCtime(),rizhi.getUrl(),rizhi.getQtype(),rizhi.getUip(),rizhi.getBiaozhi());
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
