package com.lianyi.dao.impl;

import com.lianyi.bean.Gsinfo;
import com.lianyi.bean.Gsxx;

import java.util.List;

/**
 * Created by dell on 2017/7/17.
 */
public interface ICompanyProductDao {
    public List<Gsxx> getgongsi();
    public Gsxx gscontent(int id);
}
