package com.lianyi.dao.impl;

import com.lianyi.bean.AdminUser2;
import com.lianyi.bean.Jsyh;
import com.lianyi.bean.JueSe;
import com.lianyi.dao.IYonghuDao;
import com.lianyi.exception.NewsException;
import com.lianyi.utils.JdbcUtils;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by dell on 2017/7/3.
 */
public class YonghuDaoimpl implements IYonghuDao {
    private QueryRunner queryRunner = JdbcUtils.getQuerrRunner();
    @Override

    public void addAdmin(AdminUser2 adminUser2)throws NewsException{
        String sql = "insert into adminuser(`username`,`password`,`status`) values(?,?,?)";
        try {
            queryRunner.update(sql,adminUser2.getUsername(),adminUser2.getPassword(),adminUser2.getStatus());
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public List<AdminUser2> getAll() {
        List<AdminUser2> list = new ArrayList<AdminUser2>();
        String sql = "select * from adminuser";
        try {
            list = queryRunner.query(sql,new BeanListHandler<AdminUser2>(AdminUser2.class));
        } catch (SQLException e) {
            e.printStackTrace();
        }
            return list;
    }

    @Override
    public void delete(int id) {
       String sql = "delete from adminuser where id=?";
        try {
            queryRunner.update(sql,id);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public AdminUser2 getById(int id){
        AdminUser2 juse = null;
        String sql = "select * from adminuser where id =?";
        try {
            juse= queryRunner.query(sql,new BeanHandler<AdminUser2>(AdminUser2.class),id);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return juse;
    }
    public void update(AdminUser2 adminUser2){
        String sql = "update adminuser set username=?,password=?,status=? where id=?";
        try {
            queryRunner.update(sql,adminUser2.getUsername(),adminUser2.getPassword(),adminUser2.getStatus(),adminUser2.getId());
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void juse(int uid, int rid) throws  NewsException{
        String sql = "insert into yhjs values(?,?)";
        try {
            queryRunner.update(sql,uid,rid);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public List<JueSe> getJuse() {
        String sql = "select * from juse";
        try {
            return queryRunner.query(sql,new BeanListHandler<JueSe>(JueSe.class ));
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void deleteJuse(int id) throws NewsException {
        String sql = "delete from yhjs where userid=?";
        try {
            queryRunner.update(sql,id);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public Jsyh getJuseById(int id) {
        String sql = "select yhjs.userid,juse.title from yhjs left join adminuser on yhjs.userid = adminuser.id left join juse on yhjs.roleid = juse.id where yhjs.userid=?";
        try {
            return queryRunner.query(sql,new BeanHandler<Jsyh>(Jsyh.class),id);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void shanchu(int id) {
        String sql = "delete from yhjs where userid=?";
        try {
            queryRunner.update(sql,id);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
