package com.lianyi.dao.impl;

import com.lianyi.bean.NewsBean;
import com.lianyi.bean.NewsTypeBean;
import com.lianyi.dao.INewsDao;
import com.lianyi.exception.NewsException;
import com.lianyi.utils.JdbcUtils;

import org.apache.commons.dbutils.BasicRowProcessor;
import org.apache.commons.dbutils.BeanProcessor;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.RowProcessor;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class NewsDaoImpl implements INewsDao {
    private QueryRunner qr = JdbcUtils.getQuerrRunner();
    RowProcessor processor = null;
    public NewsDaoImpl(){
        Map<String,String> map = new HashMap<>();
        map.put("type_id","typeId");
        //用构建好的HashMap建立一个BeanProcessor对象
        BeanProcessor bean = new BeanProcessor(map);
        processor = new BasicRowProcessor(bean);
    }
    @Override
    //所有新闻
    public List<NewsBean> getNewsAll() {
        String sql = "select n.*,nt.name as newType from news as n join news_type as nt on n.type_id=nt.id";
        try {
            return qr.query(sql,new BeanListHandler<NewsBean>(NewsBean.class,processor));
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    @Override
    //新闻类型
    public List<NewsTypeBean> getNewsTypeALL() {
        String sql = "select * from news_type";
        try {
            return qr.query(sql,new BeanListHandler<NewsTypeBean>(NewsTypeBean.class,processor));
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    //新增新闻
    public void addNew(NewsBean newsBean) throws NewsException {
        String sql = "insert into news(title,content,type_id) values(?,?,?)";
        try {
            qr.update(sql,newsBean.getTitle(),newsBean.getContent(),newsBean.getTypeID());
        } catch (SQLException e) {
            throw new NewsException("新增新闻失败！");
        }
    }

    @Override
    //返回一条新闻
    public NewsBean getNew(int id) throws NewsException {
        String sql = "select n.*,nt.name as newType from news as n join news_type as nt on n.type_id=nt.id where n.id=?";
        try {
            return qr.query(sql,new BeanHandler<NewsBean>(NewsBean.class,processor),id);
        } catch (SQLException e) {
            throw new NewsException("加载数据异常！");
        }
    }

    @Override
    //删除新闻
    public void deleteNew(int id) throws NewsException {
        String sql = "delete from news where id=?";
        try {
            qr.update(sql,id);
        } catch (SQLException e) {
            throw new NewsException("删除数据异常！");
        }
    }

    @Override
    //修改新闻
    public void updateNew(int id, NewsBean newsBean) throws NewsException {
        String sql = "update news set title=?,content=?,type_id=? where id=?";

        try {
            qr.update(sql,newsBean.getTitle(),newsBean.getContent(),newsBean.getTypeID(),id);
        } catch (SQLException e) {
            e.printStackTrace();
            throw new NewsException("修改数据异常！");
        }
    }

}
