package com.lianyi.dao.impl;

import com.lianyi.bean.Jsqx;
import com.lianyi.bean.Quanxian;
import com.lianyi.controller.QuanXian;
import com.lianyi.dao.IQuanxianDao;
import com.lianyi.exception.NewsException;
import com.lianyi.utils.JdbcUtils;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by dell on 2017/7/6.
 */
public class QuanxianDaoimpl implements IQuanxianDao {
    QueryRunner queryRunner = JdbcUtils.getQuerrRunner();

    @Override
    public List<Quanxian> getQuanxian() {
        List<Quanxian> list = new ArrayList<Quanxian>();
        String sql = "select *  from quanxian";
        try {
          list = queryRunner.query(sql,new BeanListHandler<Quanxian>(Quanxian.class));
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }
    public Quanxian select(int id)throws NewsException{
        String sql = "select * from quanxian where id=?";
       Quanxian quanxian = null;
        try {
          quanxian  =  queryRunner.query(sql,new BeanHandler<Quanxian>(Quanxian.class),id);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return quanxian;
    }
    @Override
    public void addQuan(String title,String q_type, String url,int status,int pid) throws NewsException{
        String sql = "insert into quanxian(`title`,`q_type`,`url`,`status`,`pid`) values(?,?,?,?,?)";
        try {
            queryRunner.update(sql,title,q_type,url,status,pid);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void deleteQuan(int id) throws NewsException {
        String sql = "delete from quanxian where id=?";
        try {
            queryRunner.update(sql,id);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void uqx(Quanxian quanxian) throws NewsException{
        String sql = "update quanxian set title=?,q_type=?,url=?,status=? where id=?";
        try {
            queryRunner.update(sql,quanxian.getTitle(),quanxian.getQ_type(),quanxian.getUrl(),quanxian.getStatus(),quanxian.getId());
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void juseqx(Jsqx jsqx ) throws NewsException {
        String sql = "insert into jsqx values(?,?)";
        try {
            queryRunner.update(sql,jsqx.getRoleid(),jsqx.getPerid());
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public List<Jsqx> getPerid(int id) {
        String sql = "select * from jsqx where roleid=?";
        try {
            return queryRunner.query(sql,new BeanListHandler<Jsqx>(Jsqx.class),id);
        } catch (SQLException e) {
            throw  new RuntimeException(e);
        }
    }

    @Override
    public void gouxuan(int id) {
        String sql = "delete from jsqx where roleid = ?";
        try {
            queryRunner.update(sql,id);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
