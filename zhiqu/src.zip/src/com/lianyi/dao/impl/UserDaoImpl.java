package com.lianyi.dao.impl;
import com.lianyi.bean.User;
import com.lianyi.dao.IUserDao;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Lenovo on 2017/6/16.
 */
public class UserDaoImpl implements IUserDao{
    @Override
    public List<User> getAllUsers() {
        //链接数据库获取数据
        List<User> users = new ArrayList<User>();
        //查询
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/sqltestdb", "root", "123");
            if (!connection.isClosed()) {
                System.out.print("连接成功");
            }
            String sql = "SELECT * from emp1";
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            ResultSet resultSet = preparedStatement.executeQuery();

            while(resultSet.next()){
                int id=resultSet.getInt(1);
                String name = resultSet.getString(2);
                User user = new User(id,name);
                users.add(user);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return users;
    }


    //增加
    @Override
    public int addUser(String name) {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/sqltestdb", "root", "123");
            if (!connection.isClosed()) {
                System.out.print("连接成功");
            }
            String sql = "INSERT INTO emp1(`name`) VALUES('"+name+"')";
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.execute();
        } catch (Exception e) {
            e.printStackTrace();
            return -1;
        }
        return 0;
    }

    @Override
    public User selectUser(int id) {
        User user = null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/sqltestdb", "root", "123");
            if (!connection.isClosed()) {
                System.out.print("连接成功");
            }
            String sql = "SELECT * from emp1 WHERE `id`="+id;
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            ResultSet resultSet = preparedStatement.executeQuery();

            while(resultSet.next()){
                int id2 = resultSet.getInt(1);
                String name = resultSet.getString(2);
                user = new User(id2,name);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return user;
    }

    //修改
    @Override
    public void updateUser(int id, String name) {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/sqltestdb", "root", "123");
            if (!connection.isClosed()) {
                System.out.print("连接成功");
            }
            String sql = "UPDATE emp1 set NAME='"+name+"' where id="+id+"";
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.execute();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    //删除
    @Override
    public int delectUser(String name) {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/sqltestdb", "root", "123");
            if (!connection.isClosed()) {
                System.out.print("连接成功");
            }
            String sql = "DELETE FROM emp1 where name='"+name+"'";
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.execute();
        } catch (Exception e) {
            e.printStackTrace();
            return -1;
        }
        return 0;
    }
}
