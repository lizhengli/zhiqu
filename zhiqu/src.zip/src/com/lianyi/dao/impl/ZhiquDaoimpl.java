package com.lianyi.dao.impl;

import com.lianyi.bean.Gongying;
import com.lianyi.dao.IzhiquDao;
import com.lianyi.dao.MyConnection;
import com.lianyi.utils.JdbcUtils;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by dell on 2017/7/4.
 */
public class ZhiquDaoimpl implements IzhiquDao {
    QueryRunner queryRunner = JdbcUtils.getQuerrRunner();
    List<Gongying> list = new ArrayList<Gongying>();
    @Override
    public List<Gongying> gongying(int id){
        String sql = "select * from supply_info2 where pid=?";
        try {
           list =  queryRunner.query(sql,new BeanListHandler<Gongying>(Gongying.class),id);
            return list;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    @Override
    public List<Gongying> xianshi(int id) {
        String sql = "select * from supply_info2 where pid=?";
        try {
           list =  queryRunner.query(sql,new BeanListHandler<Gongying>(Gongying.class),id);
            return list;
        } catch (SQLException e) {
            throw  new RuntimeException(e);
        }
    }
}
