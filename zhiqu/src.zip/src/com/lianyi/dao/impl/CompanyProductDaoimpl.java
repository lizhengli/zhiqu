package com.lianyi.dao.impl;

import com.lianyi.bean.Gsinfo;
import com.lianyi.bean.Gsxx;
import com.lianyi.utils.JdbcUtils;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by dell on 2017/7/17.
 */
public class CompanyProductDaoimpl implements ICompanyProductDao {
    QueryRunner queryRunner = JdbcUtils.getQuerrRunner();
    @Override
    public List<Gsxx> getgongsi() {
        List<Gsxx> list = new ArrayList<Gsxx>();
        String sql = "select * from gsxx";
        try {
            list = queryRunner.query(sql,new BeanListHandler<Gsxx>(Gsxx.class));
            return list;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public Gsxx gscontent(int id) {
        String sql = "select * from gsxx where yhid2=?";
        try {
           return  queryRunner.query(sql,new BeanHandler<Gsxx>(Gsxx.class),id);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}
