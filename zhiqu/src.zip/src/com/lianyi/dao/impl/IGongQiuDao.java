package com.lianyi.dao.impl;

import com.lianyi.bean.info;

import java.util.List;

/**
 * Created by dell on 2017/7/17.
 */
public interface IGongQiuDao {
    public List<info> getAll();
    public void shenhe(info info);
    public void qgshenhe(info info);
    public void gyshenhe(info info);
    public void delete(info info);
}
