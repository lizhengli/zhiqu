package com.lianyi.dao.impl;

import com.lianyi.bean.FabuRen;
import com.lianyi.bean.InfoType;
import com.lianyi.bean.NewsBean;
import com.lianyi.bean.info;
import com.lianyi.dao.IinfoTypeDao;
import com.lianyi.utils.JdbcUtils;
import org.apache.commons.beanutils.BeanMap;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Created by dell on 2017/7/16.
 */
public class IinfoTypeDaoimpl implements IinfoTypeDao {
    QueryRunner queryRunner = JdbcUtils.getQuerrRunner();
    @Override
    public List<InfoType> ftype() {
        List<InfoType> list = new ArrayList<InfoType>();
        String sql = "select * from supply_info2 where pid=0";
        try {
            list = queryRunner.query(sql,new BeanListHandler<InfoType>(InfoType.class));
            return list;
        } catch (SQLException e) {
            throw  new RuntimeException(e);
        }
    }

    @Override
    public List<InfoType> stype(int pid) {
        String sql = "select * from supply_info2 where pid=?";
        try {
           List list =  queryRunner.query(sql,new BeanListHandler<InfoType>(InfoType.class),pid);
            return list;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public List<info> infoftype(int id) {
        List<info> list = new ArrayList<info>();
        String sql ="select * from llinfo where ftype=?";
        try {
           list =  queryRunner.query(sql,new BeanListHandler<info>(info.class),id);
            return list;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public List<info> infostype(int id) {
        List<info> list = new ArrayList<info>();
        String sql ="select * from llinfo where sontype=?";
        try {
           list = queryRunner.query(sql,new BeanListHandler<info>(info.class),id);
            return list;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public FabuRen getstypeinfo(int uid, String title) {
        FabuRen fabuRen = new FabuRen();
        String sql = "select al.ctime as ftime,al.title,al.content,gs.address,gs.lxr,gs.gsname,zq.swemail,zq.phonenumber,gs.qq from llinfo as al join gsxx as gs on al.uid=gs.yhid2 join zq_yhinfo as zq on al.uid=zq.id where al.uid=? and al.title=?";
        try {
            fabuRen = queryRunner.query(sql,new BeanHandler<FabuRen>(FabuRen.class),uid,title);
            return  fabuRen;
        } catch (SQLException e) {
            throw new  RuntimeException(e);
        }
    }

    @Override
    public FabuRen getftypeinfo(int uid, String title) {
        FabuRen fabuRen = new FabuRen();
        String sql = "select al.ctime as ftime,al.title,al.content,gs.address,gs.lxr,gs.gsname,zq.swemail,zq.phonenumber,gs.qq from llinfo as al join gsxx as gs on al.uid=gs.yhid2 join zq_yhinfo as zq on al.uid=zq.id where al.uid=? and al.title=?";
        try {
            fabuRen = queryRunner.query(sql,new BeanHandler<FabuRen>(FabuRen.class),uid,title);
            return  fabuRen;
        } catch (SQLException e) {
            throw new  RuntimeException(e);
        }
    }

    @Override
    public List<info> souinfo(String n) {
        List<info> list = new ArrayList<info>();
        String sql = "select * from llinfo where title like '%"+""+n+""+"%'";
        try {
           list =  queryRunner.query(sql,new BeanListHandler<info>(info.class));
            return list;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public List<NewsBean> sounews(String n) {
        List<NewsBean> list = new ArrayList<NewsBean>();
        String sql = "select * from news where title like '%"+""+n+""+"%'";
        try {
            list = queryRunner.query(sql,new BeanListHandler<NewsBean>(NewsBean.class));
            return list;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

}
