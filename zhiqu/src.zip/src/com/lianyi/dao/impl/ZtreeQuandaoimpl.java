package com.lianyi.dao.impl;

import com.lianyi.bean.Quanxian;
import com.lianyi.dao.ZtreeQuanxian;
import com.lianyi.utils.JdbcUtils;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import java.sql.SQLException;
import java.util.List;

/**
 * Created by dell on 2017/7/8.
 */
public class ZtreeQuandaoimpl implements ZtreeQuanxian {
    QueryRunner queryRunner = JdbcUtils.getQuerrRunner();
    @Override
    public List<Quanxian> fingAll() {
        String sql = "select * from quanxian";
        try {
            return queryRunner.query(sql,new BeanListHandler<Quanxian>(Quanxian.class));
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}
