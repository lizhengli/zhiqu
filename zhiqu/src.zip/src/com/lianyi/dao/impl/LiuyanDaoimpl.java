package com.lianyi.dao.impl;

import com.lianyi.bean.FabuRen;
import com.lianyi.bean.LiuYan;
import com.lianyi.bean.info;
import com.lianyi.dao.IliuyanDao;
import com.lianyi.utils.JdbcUtils;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by dell on 2017/7/14.
 */
public class LiuyanDaoimpl implements IliuyanDao {
    QueryRunner queryRunner = JdbcUtils.getQuerrRunner();
    @Override
    public void addLiuyan(LiuYan liuYan) {
        String sql = "insert into liuyan(`lxr`,`tel`,`address`,`content`,`title`,`uid`,`faburen`) values(?,?,?,?,?,?,?)";
        try {
            queryRunner.update(sql,liuYan.getLxr(),liuYan.getTel(),liuYan.getAddress(),liuYan.getContent(),liuYan.getTitle(),liuYan.getUid(),liuYan.getFaburen());
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public List<LiuYan> xiaoxi(String fbr) {
        List<LiuYan> list = new ArrayList<LiuYan>();
        String sql = "select * from liuyan where faburen=? and status=1";
        try {
          list =   queryRunner.query(sql,new BeanListHandler<LiuYan>(LiuYan.class),fbr);
            return list;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public LiuYan liuyan(int id) {
        String sql = "select *  from liuyan where id=?";
        try {
           return  queryRunner.query(sql,new BeanHandler<LiuYan>(LiuYan.class),id);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

    }

    @Override
    public List<LiuYan> getAll() {
        String sql = "select * from liuyan";
        try {
            List<LiuYan> list = new ArrayList<>();
           list =  queryRunner.query(sql,new BeanListHandler<LiuYan>(LiuYan.class));
            return list;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void shenhe(LiuYan liuYan) {
        String sql = "update liuyan set status=? where id=?";
        try {
            queryRunner.update(sql,liuYan.getStatus(),liuYan.getId());
        }catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void delete(int id) {
        String sql = "delete from liuyan where id=?";
        try {
            queryRunner.update(sql,id);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void read(int id) {
        String sql = "update liuyan set `read`=1 where id=?";
        try {
            queryRunner.update(sql,id);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    public info infocontent(String title){
        String sql ="select * from llinfo where title=?";
        try {
           return  queryRunner.query(sql,new BeanHandler<info>(info.class),title);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}
