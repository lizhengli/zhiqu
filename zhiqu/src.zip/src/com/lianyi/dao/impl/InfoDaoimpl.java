package com.lianyi.dao.impl;

import com.lianyi.bean.*;
import com.lianyi.bean.Number;
import com.lianyi.dao.IinfoDao;
import com.lianyi.exception.NewsException;
import com.lianyi.utils.JdbcUtils;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.ResultSetHandler;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by dell on 2017/7/5.
 */
public class InfoDaoimpl implements IinfoDao{
    private QueryRunner queryRunner = JdbcUtils.getQuerrRunner();
    List<info> list = new ArrayList<info>();

    @Override
    public List<info> qiugou() {
        String sql = "select * from qiugou where status=1 order by id desc";
        try {
            list = queryRunner.query(sql,new BeanListHandler<info>(info.class));
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    @Override
    public List<info> gongying() {
        String sql = "select * from gongying where status=1 order by id desc";
        try {
            list = queryRunner.query(sql,new BeanListHandler<info>(info.class));
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    @Override
    public FabuRen getNew1(int id,String title) {
        FabuRen fabuRen = null;
        String sql = "select qg.ctime as ftime,qg.title,qg.content,gs.address,gs.lxr,gs.gsname,zq.swemail,zq.phonenumber from qiugou as qg join gsxx as gs on qg.uid=gs.yhid2 join zq_yhinfo as zq on qg.uid=zq.id where qg.uid=? and qg.title=?";
        try {
            fabuRen = queryRunner.query(sql,new BeanHandler<FabuRen>(FabuRen.class),id,title);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return fabuRen;
    }
    public Userinfo getInfo(int id){
        String sql = "select zq.name as username,zq.password,gs.gsname,zq.swemail,gs.address,zq.phonenumber from zq_yhinfo as zq join gsxx as gs on zq.id=gs.yhid2 where zq.id=?";
        try {
           return queryRunner.query(sql,new BeanHandler<Userinfo>(Userinfo.class),id);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

    }

    @Override
    public List<info> winfo(int id,int page,int shownumber) {
        String sql = "select *  from qiugou where uid=?  order by id limit "+(page-1)*shownumber+","+shownumber;
        try {
             return queryRunner.query(sql,new BeanListHandler<info>(info.class),id);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    public List<info> winfo2(int id) {
        String sql = "select *  from gongying where uid=? order by id";
        try {
            return queryRunner.query(sql,new BeanListHandler<info>(info.class),id);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void deleteqg(int id) {
        String sql = "delete from qiugou where id=?";
        try {
            queryRunner.update(sql,id);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void deletegy(int id) {
        String sql = "delete from gongying where id =?";
        try {
            queryRunner.update(sql,id);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public info allinfoftype(int id) {
        String sql = "select * from llinfo where ftype=?";
        info ifo = new info();
        try {
            ifo = queryRunner.query(sql,new BeanHandler<info>(info.class),id);
            return ifo;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public info allinfostype(int id) {
        info ifo = new info();
        String sql = "select * from llinfo where sontype=?";
        try {
           ifo =  queryRunner.query(sql,new BeanHandler<info>(info.class),id);
            return ifo;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void addllinfo(info ifo) {
        String sql = "insert into llinfo(`title`,`desc`,`ctime`,`content`,`uid`,`sontype`,`ftype`,`gqid`) values(?,?,?,?,?,?,?,?)";
        try {
            queryRunner.update(sql,ifo.getTitle(),ifo.getDesc(),ifo.getCtime(),ifo.getContent(),ifo.getUid(),ifo.getSontype(),ifo.getFtype(),ifo.getGqid());
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public List<info> getByPageNumber(int page,int shownumber,String ku) {
       int count = getCount(ku);//总条数
        int pageCount =(int) Math.ceil(((double)count)/shownumber) ;//总页数
        String sql="select * from "+ku+" where status=1 limit "+(page-1)*shownumber+","+shownumber;
        try {
           return  queryRunner.query(sql,new BeanListHandler<info>(info.class));
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }


    //获取总条数
    public int getCount(String ku){
        String sql = "select count(*) from "+ku+" where status=1";
        try {
            return queryRunner.query(sql, new ResultSetHandler<Integer>() {
                @Override
                public Integer handle(ResultSet resultSet) throws SQLException {
                    Integer i = 0;
                    while(resultSet.next()){
                        i=resultSet.getInt(1);
                    }
                    return i;
                }
            });


        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override

    public FabuRen getNew2(int id,String title){
        FabuRen fabuRen = null;
        String sql = "select gy.ctime as ftime,gy.title,gy.content,gs.address,gs.lxr,gs.gsname,zq.swemail,zq.phonenumber,gs.qq from gongying as gy join gsxx as gs on gy.uid=gs.yhid2 join zq_yhinfo as zq on gy.uid=zq.id where gy.uid=? and gy.title=?";
        try {
            fabuRen = queryRunner.query(sql,new BeanHandler<FabuRen>(FabuRen.class),id,title);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return fabuRen;
    }
    public void addinfo(info ifo) throws NewsException{
        String sql = "INSERT INTO qiugou(title,`desc`,content,uid,sontype,ftype) values(?,?,?,?,?,?)";
        try {
            queryRunner.update(sql,ifo.getTitle(),ifo.getDesc(),ifo.getContent(),ifo.getUid(),ifo.getSontype(),ifo.getFtype());
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public void addgy(info ifo) throws  NewsException{
        String sql = "INSERT INTO gongying(title,`desc`,content,uid,sontype,ftype) values(?,?,?,?,?,?)";
        try {
            queryRunner.update(sql,ifo.getTitle(),ifo.getDesc(),ifo.getContent(),ifo.getUid(),ifo.getSontype(),ifo.getFtype());
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public List<info> gerenQiugou(int id) {
        String sql = "select *  from qiugou where uid=?";
        try {
           return  queryRunner.query(sql,new BeanListHandler<info>(info.class),id);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}
