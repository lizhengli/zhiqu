package com.lianyi.dao.impl;

import com.lianyi.bean.Type;;
import com.lianyi.dao.ITypeDao;
import com.lianyi.utils.JdbcUtils;
import org.apache.commons.dbutils.BasicRowProcessor;
import org.apache.commons.dbutils.BeanProcessor;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.RowProcessor;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by Lenovo on 2017/6/26.
 */
public class TypeDaoImpl implements ITypeDao {
    private QueryRunner qr = JdbcUtils.getQuerrRunner();
    RowProcessor processor = null;
    public TypeDaoImpl(){
        Map<String,String> map = new HashMap<>();
        map.put("create_time","createTime");
        //用构建好的HashMap建立一个BeanProcessor对象
        BeanProcessor bean = new BeanProcessor(map);
        processor = new BasicRowProcessor(bean);
    }
    @Override
    public List<Type> getAll() {
        List<Type> types = new ArrayList<Type>();
        //查询
        try {
            String sql ="SELECT b1.*,b2.title as ptitle FROM best_type as b1 JOIN best_type as b2 ON (b1.pid=b2.id) UNION select * ,title as ptitle FROM  best_type where pid=0 ORDER BY create_time DESC ;";
            return qr.query(sql,new BeanListHandler<Type>(Type.class,processor));
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public List<Type> getParents() {
        return null;
    }

    @Override
    public void addType(String title,String description,int pid) {
        String sql = "INSERT INTO best_type(`title`,`pid`, `description`) VALUES (?,?,?)";
        try {
            qr.update(sql,title,pid,description);
        } catch (SQLException e) {
           throw new RuntimeException(e);
        }
    }

    @Override
    public void deleteType(int id) {
        String sql = "DELETE FROM best_type WHERE `id`=?";
        try {
            qr.update(sql,id);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public void update(int id, String title, String desc, int pid) {
        String sql = "UPDATE best_type set title=?,pid=?,description=? WHERE id=?";
        try {
            qr.update(sql,title,pid,desc,id);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public Type getTypeById(int id) {
        Type type = null;
        String sql = "SELECT  * FROM best_type WHERE id=?";
        try {
           type = qr.query(sql,new BeanHandler<Type>(Type.class,processor),id);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return type;
    }
}
