package com.lianyi.dao.impl;

import com.lianyi.bean.JueSe;
import com.lianyi.bean.Juse;
import com.lianyi.bean.Rizhi;
import com.lianyi.dao.IJuseDao;
import com.lianyi.exception.NewsException;
import com.lianyi.utils.JdbcUtils;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.w3c.dom.stylesheets.LinkStyle;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by dell on 2017/7/7.
 */
public class JuseDaoimpl implements IJuseDao{
    QueryRunner queryRunner = JdbcUtils.getQuerrRunner();
    @Override
    public List<JueSe> getAll() {
        List<JueSe> list = new ArrayList<JueSe>();
        String sql = "select * from juse";
        try {
            list = queryRunner.query(sql,new BeanListHandler<JueSe>(JueSe.class));
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return  list;
    }

    @Override
    public void addJuse(JueSe jueSe) throws NewsException{
        String sql = "insert into juse(`title`,`jsdesc`) values(?,?)";
        try {
            queryRunner.update(sql,jueSe.getTitle(),jueSe.getJsdesc());
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void delete(int id) throws NewsException{
        String sql = "delete from juse where id=?";
        try {
            queryRunner.update(sql,id);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public JueSe select(int id){
        String sql = "select * from juse where id = ?";
        JueSe jueSe = null;
        try {
          jueSe = queryRunner.query(sql,new BeanHandler<JueSe>(JueSe.class),id);
        } catch (SQLException e) {
            e.printStackTrace();
        }
            return  jueSe;
    }

    @Override
    public void update(JueSe jueSe) throws NewsException {
        String sql = "update juse set title=?,jsdesc=? where id=?";
        try {
            queryRunner.update(sql,jueSe.getTitle(),jueSe.getJsdesc(),jueSe.getId());
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public List<Rizhi> getRizhi() {
        String sql = "select * from rzjl";
        try {
          return  queryRunner.query(sql,new BeanListHandler<Rizhi>(Rizhi.class));
        } catch (SQLException e) {
            throw  new RuntimeException(e);
        }
    }
}
