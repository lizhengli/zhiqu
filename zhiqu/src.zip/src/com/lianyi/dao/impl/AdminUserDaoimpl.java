package com.lianyi.dao.impl;

import com.lianyi.bean.AdminUser;
import com.lianyi.bean.AdminUser2;
import com.lianyi.bean.ZhiQuUser;
import com.lianyi.dao.IAdminUserDao;
import com.lianyi.utils.JdbcUtils;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanMapHandler;

import java.sql.SQLException;

/**
 * Created by dell on 2017/6/28.
 */
public class AdminUserDaoimpl implements IAdminUserDao {
  private QueryRunner queryRunner = JdbcUtils.getQuerrRunner();
    AdminUser adminUser = null;
    AdminUser2 adminUser2 = null;
    @Override
   public AdminUser getZhiquUserByusrname(String username) {

        String sql = "select * from ZhiquUser where name=?";
        try {
            adminUser = queryRunner.query(sql,new BeanHandler<AdminUser>(AdminUser.class),username);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return adminUser;
    }

    @Override
    public AdminUser2 getAdminUserByusrname(String username) {
        String sql = "select * from adminuser where username=?";
        try {
            adminUser2  = queryRunner.query(sql,new BeanHandler<AdminUser2>(AdminUser2.class),username);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return adminUser2;
    }
}
