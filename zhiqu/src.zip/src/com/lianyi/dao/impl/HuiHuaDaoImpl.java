package com.lianyi.dao.impl;

import com.lianyi.bean.HuiHuaBean;
import com.lianyi.dao.IHuiHuaDao;
import com.lianyi.utils.JdbcUtils;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import java.sql.SQLException;
import java.util.List;

/**
 * Created by Lenovo on 2017/7/17.
 */
public class HuiHuaDaoImpl implements IHuiHuaDao {
    private QueryRunner qr = JdbcUtils.getQuerrRunner();
    @Override
    public void add(HuiHuaBean huiHua) {
        String sql = "INSERT INTO huihua(name,ip,sessionID,date) VALUES (?,?,?,?)";
        try {
            qr.update(sql,huiHua.getName(),huiHua.getIp(),huiHua.getSessionID(),huiHua.getDate());
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public List<HuiHuaBean> getAll() {
        String sql = "select * from huihua";
        try {
            return qr.query(sql,new BeanListHandler<HuiHuaBean>(HuiHuaBean.class));
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public HuiHuaBean getById(Integer id) {
        String sql = "select * from huihua where id=?";
        try {
            return qr.query(sql,new BeanHandler<HuiHuaBean>(HuiHuaBean.class),id);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void update(Integer id,String name) {
        String sql = "update huihua set name=? where id=?";
        try {
            qr.update(sql,name,id);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void delete(Integer id) {
        String sql = "delete from huihua where id=?";
        try {
            qr.update(sql,id);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void delete(String condition) {
        String sql = "delete from huihua where "+condition;
        try {
            qr.update(sql);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public List<HuiHuaBean> findAll() {
        return null;
    }

    @Override
    public HuiHuaBean findById(Integer id) {
        return null;
    }

    @Override
    public void save(HuiHuaBean huiHua) {

    }

    @Override
    public void deleteByCondition(String s) {

    }
}
