package com.lianyi.dao.impl;

import com.lianyi.bean.AdminUser;
import com.lianyi.bean.Gsinfo;
import com.lianyi.bean.Sheng;
import com.lianyi.bean.ZhiQuUser;
import com.lianyi.dao.MyConnection;
import com.lianyi.dao.ZhuCeDao;
import com.lianyi.utils.JdbcUtils;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by dell on 2017/6/30.
 */
public class ZhuCeDaoimpl implements ZhuCeDao {
    private QueryRunner queryRunner = JdbcUtils.getQuerrRunner();
    List<Sheng> list = new ArrayList<Sheng>();
    @Override
    public List getSheng() {
        String sql = "select * from region where father_id = 0";
        try {
            list = (ArrayList) queryRunner.query(sql,new BeanListHandler<Sheng>(Sheng.class));
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return list;
    }

    @Override
    public Map getCity(String code) {
        Map map = new HashMap<>();

        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = MyConnection.getCon();
            String sql = "select * from region where father_id = "+code;
            PreparedStatement preparedStatement = con.prepareStatement(sql);
            ResultSet res = preparedStatement.executeQuery();
            while(res.next()){
                String  sid = res.getString(3);
                String name = res.getString(2);
                map.put(sid,name);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
//        try {
//            list = (ArrayList) queryRunner.query(sql,new BeanListHandler<Sheng>(Sheng.class));
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }
        return map;
    }

    @Override
    public void userZhuce(ZhiQuUser zhiQuUser) {
        QueryRunner queryRunner = JdbcUtils.getQuerrRunner();
        String sql = "insert into zq_yhinfo(name,password,swemail,aqemail,phonenumber) values(?,?,?,?,?)";
        try {
            queryRunner.update(sql,zhiQuUser.getName(),zhiQuUser.getPassword(),zhiQuUser.getshangwu(),zhiQuUser.getAnquan(),zhiQuUser.getShouji());
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
    public void gsZhuce(Gsinfo gsinfo){
        String sql = "insert into gsxx(gsname,lxr,sex,zw,sheng,city,address,youbian,tel,chuanzhen,qq,msn,hangye,gslx,xingzhi,moshi,zczj,yingye,yuangong,zhuyao,jinchu) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        try {
            queryRunner.update(sql,gsinfo.getGongsi(),gsinfo.getLianxiren(),gsinfo.getXingbie(),gsinfo.getZhiwei(),gsinfo.getShengfen(),gsinfo.getChengshi(),gsinfo.getGongsidizhi(),gsinfo.getYoubian(),gsinfo.getGudingdianhua(),gsinfo.getChuanzhen(),gsinfo.getQq(),gsinfo.getMsn(),gsinfo.getHangyedalei(),gsinfo.getSuoshutype(),gsinfo.getQiyexingzhi(),gsinfo.getJingyingmoshi(),gsinfo.getMoney(),gsinfo.getNianmoney(),gsinfo.getGuyuan(),gsinfo.getZhuyingyewu(),gsinfo.getJinchukou());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public void addUser(AdminUser adminUser){
        String sql = "insert into zhiquuser(`name`,`password`) values(?,?)";
        try {
            queryRunner.update(sql,adminUser.getName(),adminUser.getPassword());
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }
}
