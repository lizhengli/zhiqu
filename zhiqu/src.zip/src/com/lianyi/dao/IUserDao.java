package com.lianyi.dao;

import com.lianyi.bean.User;

import java.util.List;

/**
 * Created by Lenovo on 2017/6/16.
 */
public interface IUserDao {
    public List<User> getAllUsers();
    public int addUser(String name);
    public User selectUser(int id);
    public void updateUser(int id, String name);
    public int delectUser(String name);
}
