package com.lianyi.dao;

import com.lianyi.bean.AdminUser;
import com.lianyi.bean.Gsinfo;
import com.lianyi.bean.ZhiQuUser;

import java.util.List;
import java.util.Map;

/**
 * Created by dell on 2017/6/30.
 */
public interface ZhuCeDao {
    public List getSheng();
    public Map getCity(String code);
    public void userZhuce(ZhiQuUser zhiQuUser);
    public void gsZhuce(Gsinfo gsinfo);
    public void  addUser(AdminUser adminUser);
}
