package com.lianyi.dao;

import com.lianyi.bean.FabuRen;
import com.lianyi.bean.LiuYan;
import com.lianyi.bean.info;

import java.util.List;

/**
 * Created by dell on 2017/7/14.
 */
public interface IliuyanDao {
    public void addLiuyan(LiuYan liuYan);
    public List<LiuYan> xiaoxi(String fbr);
    public LiuYan liuyan(int id);
    public List<LiuYan> getAll();
    public void shenhe(LiuYan liuYan);
    public void delete(int id);
    public void read(int id);
    public info infocontent(String title);
}
