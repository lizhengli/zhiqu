package com.lianyi.dao;

import com.lianyi.bean.JueSe;
import com.lianyi.bean.Juse;
import com.lianyi.bean.Rizhi;
import com.lianyi.exception.NewsException;

import java.sql.SQLException;
import java.util.List;

/**
 * Created by dell on 2017/7/7.
 */
public interface IJuseDao {
    public List<JueSe> getAll();
    public void addJuse(JueSe jueSe) throws NewsException;
    public void  delete(int id) throws NewsException;
    public JueSe select(int id) throws SQLException;
    public void update(JueSe jueSe) throws  NewsException;
    public List<Rizhi> getRizhi();
}
