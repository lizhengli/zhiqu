package com.lianyi.dao;

import java.sql.Connection;
import java.sql.DriverManager;

/**
 * Created by dell on 2017/6/19.
 */
public class MyConnection {
    static Connection con;
    static{
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/java","root","123456");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public static Connection getCon(){
        return con;
    }

}
