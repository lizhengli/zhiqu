package com.lianyi.dao;

import com.lianyi.bean.AdminUser;
import com.lianyi.bean.AdminUser2;
import com.lianyi.bean.ZhiQuUser;

/**
 * Created by dell on 2017/6/28.
 */
public interface IAdminUserDao {
    public AdminUser getZhiquUserByusrname(String username);
    public AdminUser2 getAdminUserByusrname(String username);
}
