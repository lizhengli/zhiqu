package com.lianyi.dao;

import com.lianyi.bean.Gongying;

import java.util.List;
import java.util.Map;

/**
 * Created by dell on 2017/7/4.
 */
public interface IzhiquDao {
       public List<Gongying> gongying(int id);
    public List<Gongying> xianshi(int id);
}
