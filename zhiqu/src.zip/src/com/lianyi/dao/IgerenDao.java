package com.lianyi.dao;

import com.lianyi.bean.FabuRen;

/**
 * Created by dell on 2017/7/13.
 */
public interface IgerenDao {
    public FabuRen getInfo(int id);
}
