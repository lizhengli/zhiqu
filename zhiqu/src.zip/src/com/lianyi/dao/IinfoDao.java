package com.lianyi.dao;

import com.lianyi.bean.*;
import com.lianyi.bean.Number;
import com.lianyi.exception.NewsException;

import java.util.List;

/**
 * Created by dell on 2017/7/5.
 */
public interface IinfoDao {
    public List<info> qiugou();
    public List<info> gongying();
    public FabuRen getNew1(int id,String title);
    public FabuRen getNew2(int id,String title);
    public void addinfo(info ifo) throws NewsException;
    public void addgy(info ifo)throws NewsException;
    public List<info> gerenQiugou(int id);
    public Userinfo getInfo(int id);
    public List<info> winfo(int id,int page,int shownumber);
    public List<info> winfo2(int id);
    public void deleteqg(int id);
    public void deletegy(int id);
    public info allinfoftype(int id);
    public info allinfostype(int id);
    public void addllinfo(info ifo);
    public List<info> getByPageNumber(int page,int shownumber,String ku);
    public int getCount(String ku);
}
