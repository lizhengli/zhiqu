package com.lianyi.dao;

import com.lianyi.bean.Quanxian;

import java.util.List;

/**
 * Created by dell on 2017/7/8.
 */
public interface ZtreeQuanxian {
    public List<Quanxian> fingAll();
}
