package com.lianyi.dao;

import com.lianyi.bean.AdminUser2;
import com.lianyi.bean.Jsyh;
import com.lianyi.bean.JueSe;
import com.lianyi.exception.NewsException;

import java.util.List;

/**
 * Created by dell on 2017/7/3.
 */
public interface IYonghuDao {
    public void addAdmin(AdminUser2 juse) throws NewsException;
    public List<AdminUser2> getAll();
    public void delete(int id);
    public AdminUser2 getById(int id);
    public void update(AdminUser2 adminUser2);
    public void juse(int urd,int rid) throws NewsException;
    public List<JueSe> getJuse();
    public void deleteJuse(int id) throws NewsException;
    public Jsyh getJuseById(int id);
    public void shanchu(int id);
}
