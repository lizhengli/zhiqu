package com.lianyi.dao;

import com.lianyi.bean.GuoLv;
import com.lianyi.bean.Rizhi;

import java.util.List;

/**
 * Created by dell on 2017/7/11.
 */
public interface IGuolvDao {
    public GuoLv roleid(int id);
    public List<GuoLv> getUrl(int id);
    public void rzjl(Rizhi rizhi);
}
