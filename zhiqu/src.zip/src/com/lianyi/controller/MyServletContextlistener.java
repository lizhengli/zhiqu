package com.lianyi.controller;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.http.HttpSession;

/**
 * Created by dell on 2017/7/17.
 */
public class MyServletContextlistener implements ServletContextListener {
    int i;
    @Override
    public void contextInitialized(ServletContextEvent event) {
        // System.out.println("创建了");
    }

    @Override
    public void contextDestroyed(ServletContextEvent event) {

    }
}
