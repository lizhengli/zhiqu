package com.lianyi.controller;

import com.lianyi.utils.VerifyCodeUtils;

import javax.imageio.ImageIO;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Random;

/**
 * Created by dell on 2017/7/3.
 */
public class VerifyImage extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setHeader("Pragma","No-catch");
        resp.setHeader("Catch-control","no-catch");
        resp.setDateHeader("Expires",0);
        resp.setContentType("image/jpeg");
        HttpSession session = req.getSession(true);
        String code = VerifyCodeUtils.generateVerifyCode(4);
        session.setAttribute("vcode",code);
        VerifyCodeUtils.outputImage(100,30,resp.getOutputStream(),code);
//        BufferedImage bufferedImage = new BufferedImage(100,30,BufferedImage.TYPE_3BYTE_BGR);//创建画布 创建图片
//        Random random = new Random();
//        Graphics2D g2 = bufferedImage.createGraphics();//创建画笔
//        g2.setRenderingHint(RenderingHints.KEY_ALPHA_INTERPOLATION,RenderingHints.VALUE_ANTIALIAS_ON);
//        g2.setColor(Color.WHITE);
//        g2.drawString("ss",30,20);
//        FileOutputStream fileOutputStream = new FileOutputStream(new File("D:/yanzheng.jpg"));
//        //imageIo将图片写到流当中
//        ImageIO.write(bufferedImage,"jpg",resp.getOutputStream());
    }
}
