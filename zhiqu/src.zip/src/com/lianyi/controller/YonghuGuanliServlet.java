package com.lianyi.controller;

import com.alibaba.fastjson.JSON;
import com.lianyi.bean.AdminUser2;
import com.lianyi.bean.Jsyh;
import com.lianyi.bean.JueSe;
import com.lianyi.bean.Juse;
import com.lianyi.exception.NewsException;
import com.lianyi.service.IYonghuService;
import com.lianyi.service.impl.Yonghuimpl;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by dell on 2017/7/3.
 */
public class YonghuGuanliServlet extends HttpServlet {
    IYonghuService iYonghuService = new Yonghuimpl();
    List<AdminUser2> list = new ArrayList<AdminUser2>();
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req,resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String method = req.getParameter("m");
        if("getAll".equals(method)){
            getAllUser(req,resp);
        }else if("delete".equals(method)){
            delete(req,resp);
        }else if("getbyid".equals(method)){
            getById(req,resp);
        }else if (method.equals("add")){
            addAdmin(req, resp);
        }else if (method.equals("update")){
            update(req, resp);
        }else if(method.equals("juse")){
            juse(req, resp);
        }else if (method.equals("getJuse")){
            getJuse(req, resp);
        }else if (method.equals("deleteJuse")){
            deleteJuse(req, resp);
        }else if(method.equals("getJuseById")){
           getJuseById(req, resp);
        }
    }
    public void getAllUser(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
       list =  iYonghuService.getAll();
        String json = JSON.toJSONString(list);
        resp.setContentType("text/json;charset=UTF-8");
        resp.getWriter().write(json);
        //this.getServletConfig().getServletContext().getRequestDispatcher("/type/yonghu.jsp").forward(req,resp);

    }
    public  void addAdmin(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
        resp.setContentType("text/json;charset=UTF-8");
        String username = req.getParameter("username");
        String password = req.getParameter("password");
        int status = Integer.parseInt(req.getParameter("status"));
        AdminUser2  adminUser2 =new AdminUser2(username,password,status);
        try {
            iYonghuService.addAdmin(adminUser2);
            resp.getWriter().write("{\"message\":\"添加成功\"}");

        } catch (NewsException e) {
            resp.getWriter().write(e.getMessage());
        }
//        try {
//            iYonghuService.addAdmin(juse);
//            resp.getWriter().write("{\"message\":\"增加成功\"}");
//        } catch (NewsException e) {
//            resp.getWriter().write(e.getMessage());
//        }
    }
    public void delete(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
        int id = Integer.parseInt(req.getParameter("id"));
        iYonghuService.delete(id);
        resp.setContentType("text/json;charset=UTF-8");
        resp.getWriter().write("{\"message\":\"删除成功\"}");
    }
    public void update(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
        int id =  Integer.parseInt(req.getParameter("id"));
        String username =req.getParameter("username");
        String password = req.getParameter("password");
        int status = Integer.parseInt(req.getParameter("status"));
        AdminUser2 adminuser2 = new AdminUser2(username,password,status,id);
        iYonghuService.update(adminuser2);
        resp.setContentType("text/json;charset=UTF-8");
        resp.getWriter().write("{\"message\":\"修改成功\"}");
    }
    public void getById(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
        int id = Integer.parseInt(req.getParameter("id"));
        AdminUser2 adminuser2 = iYonghuService.getById(id);
        req.setAttribute("user",adminuser2);
        this.getServletConfig().getServletContext().getRequestDispatcher("/type/updateyh.jsp").forward(req,resp);

    }
    public void juse(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
        resp.setContentType("text/json;charset=UTF-8");
        int rid = Integer.parseInt(req.getParameter("rid"));
        int userid = Integer.parseInt(req.getParameter("uid"));
        iYonghuService.shanchu(userid);
        try {
            iYonghuService.juse(userid,rid);
            resp.getWriter().write("{\"message\":\"设置成功\"}");
        } catch (NewsException e) {
            resp.getWriter().write(e.getMessage());
        }

    }
    public void deleteJuse(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
        resp.setContentType("text/json;charset=UTF-8");
        int id = Integer.parseInt(req.getParameter("uid"));
        try {
            iYonghuService.deleteJuse(id);
            resp.getWriter().write("{\"message\":\"删除成功\"}");
        } catch (NewsException e) {
            resp.getWriter().write(e.getMessage());
        }

    }
    public void getJuse(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
        List<JueSe> list = iYonghuService.getJuse();
        resp.setContentType("text/json;charset=UTF-8");
        req.setAttribute("juse",list);
        this.getServletConfig().getServletContext().getRequestDispatcher("/type/yonghu.jsp").forward(req,resp);
    }
    public void getJuseById(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
        int id = Integer.parseInt(req.getParameter("rid"));
        Jsyh jsyh = iYonghuService.getJuseById(id);
        req.setAttribute("jjs",jsyh);
        this.getServletConfig().getServletContext().getRequestDispatcher("/type/chakanjuse.jsp").forward(req,resp);

    }
}
