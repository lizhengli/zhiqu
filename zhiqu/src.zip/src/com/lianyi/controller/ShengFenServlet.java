package com.lianyi.controller;

import com.lianyi.bean.Gsinfo;
import com.lianyi.bean.Sheng;
import com.lianyi.bean.ZhiQuUser;
import com.lianyi.service.IZhuCeService;
import com.lianyi.service.impl.Zhuceimpl;
import org.apache.commons.beanutils.BeanUtils;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.lang.reflect.InvocationTargetException;
import java.util.*;

/**
 * Created by dell on 2017/6/30.
 */
public class ShengFenServlet extends HttpServlet {
    Map map = new HashMap<>();
    IZhuCeService iZhuCeService = new Zhuceimpl();
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req,resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String method = req.getParameter("m");
        if("getCity".equals(method)){
            getCity(req,resp);
       }else{
            sheng(req,resp);
        }
    }
    public void sheng(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
        List<Sheng> list = new ArrayList<Sheng>();
        list = iZhuCeService.getSheng();
        req.setAttribute("sheng",list);
        this.getServletConfig().getServletContext().getRequestDispatcher("/Users/zhuce.jsp").forward(req,resp);

    }
    public void getCity(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
        String code = req.getParameter("code");
        map = iZhuCeService.getCity(code);
        System.out.println(code);
        String str = "<option value=\"\">-请选择-</option>";
        Set<String> set = map.keySet();
        for(String s:set){
            String option = "<option value=\""+s+"\">"+map.get(s)+"</option>";
            str+=option;
        }
        resp.setContentType("text/html;charset=utf-8");
        PrintWriter out = resp.getWriter();
        out.println(str);
        out.flush();
        out.close();

    }
    public void zhuce(HttpServletRequest req, HttpServletResponse resp)throws ServletException, IOException{
        Map<String,String[]> map = req.getParameterMap();
        ZhiQuUser zhiQuUser = new ZhiQuUser();
        Gsinfo gsinfo = new Gsinfo();
        try {
            BeanUtils.populate(zhiQuUser,map);
            //BeanUtils.populate(gsinfo,map);
            iZhuCeService.userZhuce(zhiQuUser);
            //iZhuCeService.gsZhuce(gsinfo);
            System.out.print(zhiQuUser.getName());
            System.out.println("注册成功");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
