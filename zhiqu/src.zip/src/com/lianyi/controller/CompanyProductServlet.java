package com.lianyi.controller;

import com.lianyi.bean.Gsinfo;
import com.lianyi.bean.Gsxx;
import com.lianyi.service.impl.ComProServiceimpl;
import com.lianyi.service.impl.IComproService;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by dell on 2017/7/17.
 */
public class CompanyProductServlet extends HttpServlet {
    IComproService iComproService = new ComProServiceimpl();
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String m = req.getParameter("m");
        if (m.equals("getgongsi")){
            getgongsi(req, resp);
        }else if(m.equals("getproduct")){
            getproduct(req, resp);
        }else if (m.equals("gscontent")){
            gscontent(req, resp);
        }
    }
    public void getgongsi(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
        List<Gsxx> list = new ArrayList<Gsxx>();
        list = iComproService.getgongsi();
        req.setAttribute("gongsi",list);
        this.getServletConfig().getServletContext().getRequestDispatcher("/zhiqu/company.jsp").forward(req,resp);
    }
    public void gscontent(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
        int id = Integer.parseInt(req.getParameter("id"));
        Gsxx gsxx = iComproService.gscontent(id);
        req.setAttribute("gsinfo",gsxx);
        this.getServletConfig().getServletContext().getRequestDispatcher("/zhiqu/gscontent.jsp").forward(req,resp);

    }
    public void getproduct(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{

    }
    public void cpcontent(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{

    }
}
