package com.lianyi.controller;

import com.lianyi.bean.AdminUser;
import com.lianyi.bean.Gsinfo;
import com.lianyi.bean.Name;
import com.lianyi.bean.ZhiQuUser;
import com.lianyi.service.IAdminUserService;
import com.lianyi.service.IZhuCeService;
import com.lianyi.service.impl.AdminUserServiceimpl;
import com.lianyi.service.impl.Zhuceimpl;
import org.apache.commons.beanutils.BeanUtils;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Map;

/**
 * Created by dell on 2017/7/2.
 */
public class ZhuceServlet extends HttpServlet {
    IZhuCeService iZhuCeService = new Zhuceimpl();
    IAdminUserService iAdminUserService = new AdminUserServiceimpl();
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req,resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        String aname = req.getParameter("name");
        String password = req.getParameter("password");
        AdminUser adminUser = new AdminUser(aname,password);
        iZhuCeService.addUser(adminUser);
        Map<String,String[]> map = req.getParameterMap();
        ZhiQuUser zhiQuUser = new ZhiQuUser();
        Gsinfo gsinfo = new Gsinfo();
        try {
            BeanUtils.populate(zhiQuUser,map);
            iZhuCeService.userZhuce(zhiQuUser);
            BeanUtils.populate(gsinfo,map);
            iZhuCeService.gsZhuce(gsinfo);
            resp.setContentType("text/html;charset=UTF-8");
            resp.getWriter().write("注册成功");
            this.getServletConfig().getServletContext().getRequestDispatcher("/Users/zhuce.jsp").forward(req,resp);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
