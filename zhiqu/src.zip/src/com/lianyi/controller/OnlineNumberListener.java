package com.lianyi.controller;

import com.lianyi.Factory.BeanFactory;
import com.lianyi.bean.HuiHuaBean;
import com.lianyi.service.IHuiHuaService;
import com.lianyi.service.impl.HuiHuaServiceImpl;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by Lenovo on 2017/7/17.
 */
public class OnlineNumberListener implements HttpSessionListener {
    private static Integer activesessions = 0;
    private static Map<String,HttpSession> map = new HashMap<>();
    /*private Service<HuiHuaBean> service = BeanFactory.getInstance("huiHuaService", HuiHuaServiceImpl.class);*/
    private IHuiHuaService iHuiHuaService = new HuiHuaServiceImpl();

    public OnlineNumberListener() throws IllegalAccessException, InstantiationException, ClassNotFoundException {
    }

    @Override
    public void sessionCreated(HttpSessionEvent se) {
        HttpSession session = se.getSession();
        ServletContext context = session.getServletContext();
//        activesessions = (Integer) context.getAttribute("onLineCount");
//        if(activesessions==null){
////            context.setAttribute("onLineCount", 1);
//        }else{
        activesessions++;
//            context.setAttribute("onLineCount", activesessions);
        //sessionID
        System.out.println(session.getId());
        String sessionId = session.getId();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date d = new Date();
        //时间
        String date = sdf.format(d);
        String name = "会话"+activesessions;
        map.put(sessionId,session);
        HuiHuaBean huiHua = new HuiHuaBean();
        huiHua.setIp("");
        huiHua.setName(name);
        huiHua.setSessionID(sessionId);
        huiHua.setDate(date);
        iHuiHuaService.save(huiHua);
//        }
    }

    @Override
    public void sessionDestroyed(HttpSessionEvent se) {
        HttpSession session = se.getSession();
        ServletContext context = session.getServletContext();
//        if(activesessions==null){
//            context.setAttribute("onLineCount", 1);
//        }else{
        activesessions--;
        context.setAttribute("onLineCount", activesessions);
        //sessionID
        String sessionId = session.getId();
        map.remove(sessionId);
        iHuiHuaService.deleteByCondition("sessionID='"+sessionId+"'");
//        }
    }
    public static int getactivesessions() {
        return activesessions;
    }
    public static void deleteSession(String sessionId){
        map.get(sessionId).invalidate();
        map.remove(sessionId);
    }
}
