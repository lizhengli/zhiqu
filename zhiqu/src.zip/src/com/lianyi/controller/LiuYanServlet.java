package com.lianyi.controller;

import com.alibaba.fastjson.JSON;
import com.lianyi.bean.LiuYan;
import com.lianyi.bean.info;
import com.lianyi.service.IliuYanService;
import com.lianyi.service.impl.LiuyanServiceimpl;
import org.apache.commons.beanutils.BeanUtils;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Created by dell on 2017/7/14.
 */
public class LiuYanServlet extends HttpServlet {
    IliuYanService iliuYanService = new LiuyanServiceimpl();
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req,resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String method = req.getParameter("m");
        if (method.equals("liuyan")){
            liuyan(req, resp);
        }else if (method.equals("xiaoxi")){
            xiaoxi(req, resp);
        }else if (method.equals("liu")){
            liu(req, resp);
        }else if(method.equals("getAll")){
            getAll(req, resp);
        }else if (method.equals("shenhe")){
            shenhe(req, resp);
        }else if (method.equals("delete")){
            delete(req, resp);
        }else if (method.equals("read")){
            read(req, resp);
        }
    }
    public void liuyan(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
        resp.setContentType("text/html;charset=UTF-8");
        String lxr = req.getParameter("lxr");
        String tel = req.getParameter("tel");
        String address = req.getParameter("address");
        String content = req.getParameter("content");
        String title = req.getParameter("title");
        String faburen = req.getParameter("fbr");
        int uid = 0;
        Cookie[] cookies = req.getCookies();
        for (Cookie c:cookies){
            if (c.getName().equals("qid")){
                uid = Integer.parseInt(c.getValue());
            }
        }
        LiuYan liuYan = new LiuYan(lxr,tel,address,content,title,uid,faburen);
        iliuYanService.addLiuyan(liuYan);
        resp.getWriter().write("{\"message\":\"留言成功\"}");
    }
    public void xiaoxi(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
        int id = Integer.parseInt(req.getParameter("id"));
        iliuYanService.read(id);
        Cookie[] cookies = req.getCookies();
        String fbr ="";
        for (Cookie c:cookies){
            if (c.getName().equals("username1")){
                fbr=c.getValue();
            }
        }
        LiuYan liuYan = iliuYanService.liuyan(id);
        req.setAttribute("xiaoxi",liuYan);
        this.getServletConfig().getServletContext().getRequestDispatcher("/Users/xiaoxi.jsp").forward(req,resp);
    }
    public void liu(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{

        Cookie[] cookies = req.getCookies();
        String fbr ="";
        for (Cookie c:cookies){
            if (c.getName().equals("username1")){
                fbr=c.getValue();
            }
        }
        System.out.println(fbr+"====");
        List<LiuYan> list2 = new ArrayList<LiuYan>();
        list2 = iliuYanService.xiaoxi(fbr);
        req.setAttribute("liuyan",list2);
        this.getServletConfig().getServletContext().getRequestDispatcher("/Users/liuyan.jsp").forward(req,resp);
    }
    public void getAll(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
        resp.setContentType("text/html;charset=UTF-8");
        List<LiuYan> list = new ArrayList<LiuYan>();
        list = iliuYanService.getAll();
        String json = JSON.toJSONString(list);
        resp.getWriter().write(json);
    }
    public void shenhe(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
        resp.setContentType("text/html;charset=UTF-8");
        LiuYan liuYan = new LiuYan();
        Map map = req.getParameterMap();
        try {
            BeanUtils.populate(liuYan,map);
            iliuYanService.shenhe(liuYan);
            resp.getWriter().write("{\"message\":\"审核完毕\"}");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public void delete(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
        resp.setContentType("text/html;charset=UTF-8");
        int id = Integer.parseInt(req.getParameter("id"));
        iliuYanService.delete(id);
        resp.getWriter().write("{\"message\":\"删除成功\"}");
    }
    public void read(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
        String sql = req.getParameter("title");
        info ifo = new info();
        ifo = iliuYanService.infocontent(sql);
        req.setAttribute("info",ifo);
        this.getServletConfig().getServletContext().getRequestDispatcher("/Users/liuyanxinwen.jsp").forward(req,resp);
    }
}
