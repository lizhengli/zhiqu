package com.lianyi.controller;

import com.lianyi.service.IUserService;
import com.lianyi.service.impl.UserServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Created by Lenovo on 2017/6/19.
 */
public class UserUpdateSaveServlet extends HttpServlet{
    IUserService iUserService = new UserServiceImpl();
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String id = req.getParameter("id");
        String name = req.getParameter("name");
        iUserService.updateUser(Integer.parseInt(id),name);
        req.setAttribute("message","修改成功");
        this.getServletConfig().getServletContext().getRequestDispatcher("/success.jsp").forward(req,resp);
    }
}
