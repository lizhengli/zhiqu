package com.lianyi.controller;

import com.alibaba.fastjson.JSON;
import com.lianyi.bean.*;
import com.lianyi.bean.Number;
import com.lianyi.exception.NewsException;
import com.lianyi.service.IinfoService;
import com.lianyi.service.impl.InfoServiceimpl;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.*;
import java.util.List;

/**
 * Created by dell on 2017/7/5.
 */
public class InfoServlet extends HttpServlet {
    IinfoService iinfoService = new InfoServiceimpl();
    List<info> list = new ArrayList<info>();
    int page;
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req,resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String method = req.getParameter("m");
        if (method.equals("qiugou")){
            qiugou(req, resp);
        }else if (method.equals("gongying")){
            gongying(req, resp);
        }else if(method.equals("new1")){
            new1(req, resp);
        }else if(method.equals("new2")){
            new2(req, resp);
        }else if(method.equals("addinfo")){
            addinfo(req, resp);
        }else if(method.equals("addgy")){
            addgy(req, resp);
        }else if(method.equals("geren")){

        }else if(method.equals("gerenQiugou")){
            gerenQiugou(req, resp);
        }else if (method.equals("getInfo")){
            geren(req, resp);
        }else if (method.equals("wg")||method.equals("wq")){
            winfo(req, resp);
        }else if (method.equals("dq")||method.equals("dg")){
            deletegq(req, resp);
        }
    }
    public void geren(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
        int id = Integer.parseInt(req.getParameter("qid"));
        Userinfo userinfo = iinfoService.getInfo(id);
        req.setAttribute("user",userinfo);
        this.getServletConfig().getServletContext().getRequestDispatcher("/Users/ziliao.jsp").forward(req,resp);
    }
    public void qiugou(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
        resp.setContentType("text/html;charset=UTF-8");
        String page2=req.getParameter("page");
        if(page2.equals("0")){
            page=1;
        }else if("s".equals(page2)){
            page-=1;
        }else if("x".equals(page2)){
            page+=1;
        }else{
            page=Integer.parseInt(page2);
        }
        int shownumber =10;
        String ku = "qiugou";
        int count = iinfoService.getCount(ku);
        int pageCount = (int)(Math.ceil(((double)count)/10));//页数
        List<Number> lpage = new ArrayList<Number>();
        for (int i=1;i<=pageCount;i++){
            Number number2 = new Number(i);
            lpage.add(number2);
        }
        if(page<=0){
            page=1;
        }else if(page>pageCount){
            page=pageCount;
        }
        System.out.println(page);
        list =  iinfoService.getByPageNumber(page,shownumber,ku);
        req.setAttribute("yeshu",lpage);
        req.setAttribute("qiugou",list);
        this.getServletConfig().getServletContext().getRequestDispatcher("/zhiqu/qiugou.jsp").forward(req,resp);
    }
    public void gongying (HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
        resp.setContentType("text/html;charset=UTF-8");
        String page2=req.getParameter("page");
        if(page2.equals("0")){
            page=1;
        }else if("s".equals(page2)){
            page-=1;
        }else if("x".equals(page2)){
            page+=1;
        }else{
            page=Integer.parseInt(page2);
        }
        int shownumber =10;
        String ku = "gongying";
        int count = iinfoService.getCount(ku);
        int pageCount = (int)(Math.ceil(((double)count)/10));//页数
        List<Number> lpage = new ArrayList<Number>();
        for (int i=1;i<=pageCount;i++){
            Number number2 = new Number(i);
            lpage.add(number2);
        }
        if(page<=0){
            page=1;
        }else if(page>pageCount){
            page=pageCount;
        }
        System.out.println(page);
        list =  iinfoService.getByPageNumber(page,shownumber,ku);
        req.setAttribute("yeshu",lpage);
        req.setAttribute("gongying",list);
        this.getServletConfig().getServletContext().getRequestDispatcher("/zhiqu/gongying.jsp").forward(req,resp);
    }
    public void new1 (HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
        resp.setContentType("text/html;charset=UTF-8");
        int id = Integer.parseInt(req.getParameter("id"));
        String title=req.getParameter("title");
        FabuRen fabuRen = iinfoService.getNew1(id,title);
        req.setAttribute("fabu",fabuRen);
        this.getServletConfig().getServletContext().getRequestDispatcher("/zhiqu/qgneirong.jsp").forward(req,resp);
    }
    public void new2(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
        resp.setContentType("text/html;charset=UTF-8");
        int id = Integer.parseInt(req.getParameter("id"));
        System.out.println(id);
        String title = req.getParameter("title");
        System.out.println(title);
        FabuRen fabuRen = iinfoService.getNew2(id,title);
        req.setAttribute("fbu",fabuRen);
        System.out.println(fabuRen);
        this.getServletConfig().getServletContext().getRequestDispatcher("/zhiqu/gyinfo.jsp").forward(req,resp);
    }
    public void addinfo(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
        resp.setContentType("text/html;charset=UTF-8");
        String title = req.getParameter("title");
        String desc = req.getParameter("desc");
        String content = req.getParameter("content");
        int sontype = Integer.parseInt(req.getParameter("stype"));
        int ftype = Integer.parseInt(req.getParameter("ftype"));
        Cookie[] cookies = req.getCookies();
        Map<String,Cookie> mapC = new HashMap<String,Cookie>();
        for(Cookie c:cookies){
            mapC.put(c.getName(),c);
        }

        int uid = Integer.parseInt(mapC.get("qid").getValue());
        info ifo = new info(title,desc,content,uid,sontype,ftype,1);
        try {
            iinfoService.addinfo1(ifo);
            iinfoService.addllinfo(ifo);
            resp.getWriter().write("{\"message\":\"发布成功\"}");
        } catch (NewsException e) {
            resp.getWriter().write(e.getMessage());
        }

    }
    public void addgy(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
        resp.setContentType("text/html;charset=UTF-8");
        String title = req.getParameter("title");
        String desc = req.getParameter("desc");
        String content = req.getParameter("content");
        int sontype = Integer.parseInt(req.getParameter("stype"));
        int ftype = Integer.parseInt(req.getParameter("ftype"));
        Cookie[] cookies = req.getCookies();
        Map<String,Cookie> mapC = new HashMap<String,Cookie>();
        for(Cookie c:cookies){
            mapC.put(c.getName(),c);
        }
        int uid = Integer.parseInt(mapC.get("qid").getValue());
        info ifo = new info(title,desc,content,uid,sontype,ftype,2);
        try {
            iinfoService.addgy(ifo);
            iinfoService.addllinfo(ifo);
            resp.getWriter().write("{\"message\":\"发布成功\"}");
        } catch (NewsException e) {
            resp.getWriter().write(e.getMessage());
        }

    }
    public void gerenQiugou(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
        int id = Integer.parseInt(req.getParameter("id"));
        list = iinfoService.gerenQiugou(id);
        String json = JSON.toJSONString(list);
        resp.getWriter().write(json);
    }
    public void winfo(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
        List<info> list = new ArrayList<info>();
        //获取当前登录用户传进去的ID
        Cookie[] cookies = req.getCookies();
        int id=0;
        for (Cookie c:cookies){
            if (c.getName().equals("qid")){
                id= Integer.parseInt(c.getValue());
                break;
            }
        }
        System.out.println(id);
        String method = req.getParameter("m");
        //传进来的m=wg就查供应qg就查求购
        if (method.equals("wg")){
           list =  iinfoService.winfo2(id);
            req.setAttribute("wg",list);
           for (info l:list){
               System.out.println(l.getTitle());
           }
            this.getServletConfig().getServletContext().getRequestDispatcher("/Users/mygongying.jsp").forward(req,resp);
        }else if (method.equals("wq")){
            resp.setContentType("text/html;charset=UTF-8");
            String page2=req.getParameter("page");
            if(page2.equals("0")){
                page=1;
            }else if("s".equals(page2)){
                page-=1;
            }else if("x".equals(page2)){
                page+=1;
            }else{
                page=Integer.parseInt(page2);
            }
            int shownumber =7;
            String ku = "qiugou";
            int count = iinfoService.getCount(ku);
            int pageCount = (int)(Math.ceil(((double)count)/10));//页数
            List<Number> lpage = new ArrayList<Number>();
            for (int i=1;i<=pageCount;i++){
                Number number2 = new Number(i);
                lpage.add(number2);
            }
            if(page<=0){
                page=1;
            }else if(page>pageCount){
                page=pageCount;
            }
            System.out.println("yonghuid"+id);
           list = iinfoService.winfo(id,page,shownumber);
            req.setAttribute("yeshu",lpage);
            req.setAttribute("wq",list);
            this.getServletConfig().getServletContext().getRequestDispatcher("/Users/myqiugou.jsp").forward(req,resp);
        }
    }
    public void deletegq(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
        resp.setContentType("text/json;charset=UTF-8");
        String method = req.getParameter("m");
        int id = Integer.parseInt(req.getParameter("id"));
        System.out.println("lsdhhs"+id);
        if (method.equals("dq")){
            iinfoService.deleteqg(id);
            resp.getWriter().write("{\"message\":\"删除成功\"}");
        }else if (method.equals("dg")){
            iinfoService.deletegy(id);
            resp.getWriter().write("{\"message\":\"删除成功\"}");
        }
    }

}
