package com.lianyi.controller;

import com.alibaba.fastjson.JSON;
import com.lianyi.bean.info;
import com.lianyi.service.IGongQiuServie;
import com.lianyi.service.impl.GongQiuServiceimpl;
import org.apache.commons.beanutils.BeanUtils;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Created by dell on 2017/7/17.
 */
public class GongQiuguanliServlet extends HttpServlet {
    IGongQiuServie iGongQiuServie = new GongQiuServiceimpl();
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req,resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String m = req.getParameter("m");
        if (m.equals("getAll")){
            getAll(req, resp);
        }else if (m.equals("shenhe")){
            shenhe(req, resp);
        }else if(m.equals("delete")){
            delete(req, resp);
        }
    }
    public void getAll(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
        resp.setContentType("text/json;charset=UTF-8");
        List<info> list = new ArrayList<>();
        list = iGongQiuServie.getAll();
        String  json = JSON.toJSONString(list);
        resp.getWriter().write(json);
    }
    public void shenhe(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
        resp.setContentType("text/json;charset=UTF-8");
        info ifo = new info();
        Map map = req.getParameterMap();
        try {
            BeanUtils.populate(ifo,map);
            System.out.println(ifo);
            iGongQiuServie.shenhe(ifo);
            resp.getWriter().write("{\"message\":\"审核完毕\"}");
        } catch (Exception e) {
            e.printStackTrace();
        }
//        int id = Integer.parseInt(req.getParameter("id"));
//        String title = req.getParameter("title");
//        int uid = Integer.parseInt(req.getParameter("uid"));
//        int status = Integer.parseInt(req.getParameter("status"));
//        int gqid = Integer.parseInt(req.getParameter("gqid"));
//        info ifo = new info(gqid,status,id,title,uid);

    }
    public void delete(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
        resp.setContentType("text/json;charset=UTF-8");
        info ifo = new info();
        Map map = req.getParameterMap();
        System.out.println(ifo);
        try {
            BeanUtils.populate(ifo,map);
            iGongQiuServie.delete(ifo);
            resp.getWriter().write("{\"message\":a\"删除成功\"}");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
