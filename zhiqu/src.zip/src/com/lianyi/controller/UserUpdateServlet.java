package com.lianyi.controller;


import com.lianyi.bean.User;
import com.lianyi.service.IUserService;
import com.lianyi.service.impl.UserServiceImpl;
import com.lianyi.exception.UserException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Created by Lenovo on 2017/6/19.
 */
public class UserUpdateServlet extends HttpServlet{
    IUserService iUserService = new UserServiceImpl();
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        int id = Integer.parseInt(req.getParameter("id"));
        //首先根据id查询出对应的数据
        User user = null;
        try {
          user = iUserService.selectUser(id);
        } catch (UserException e) {
            e.printStackTrace();
            req.setAttribute("message","错误"+e.getMessage());
            this.getServletConfig().getServletContext().getRequestDispatcher("/success.jsp").forward(req,resp);
        }
        req.setAttribute("user",user);
        this.getServletConfig().getServletContext().getRequestDispatcher("/Users/update.jsp").forward(req,resp);
    }
}
