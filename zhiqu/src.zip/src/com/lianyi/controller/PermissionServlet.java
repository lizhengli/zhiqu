package com.lianyi.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.PropertyNamingStrategy;
import com.alibaba.fastjson.serializer.SerializeConfig;
import com.lianyi.bean.Jsqx;
import com.lianyi.bean.Quanxian;
import com.lianyi.bean.ZtreeData;
import com.lianyi.exception.NewsException;
import com.lianyi.service.IQuanxianService;
import com.lianyi.service.impl.QuanxianServiceimpl;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by dell on 2017/7/8.
 */
public class PermissionServlet extends HttpServlet {
    IQuanxianService iQuanxianService = new QuanxianServiceimpl();
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
       String method = req.getParameter("m");
       if(method.equals("juseqx")){
            juseqx(req,resp);
        }else if (method.equals("ztree")){
           findAll(req,resp);
       }else if (method.equals("send")){
           sendRid(req, resp);
       }

    }
    public void sendRid(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
        int rid = Integer.parseInt(req.getParameter("rid"));
        req.setAttribute("rid",rid);
        this.getServletConfig().getServletContext().getRequestDispatcher("/zhiqu/permission.jsp").forward(req,resp);

    }
    public void findAll(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
        resp.setContentType("text/json;charset=UTF-8");
        //获取角色的ID
        int id = Integer.parseInt(req.getParameter("rid"));
        //角色的权限
        List<Jsqx> pid = new ArrayList<Jsqx>();
        pid = iQuanxianService.getPerid(id);
        //所有的权限
        List<Quanxian> list = new ArrayList<Quanxian>();
        list =  iQuanxianService.getQuanxian();
        //ztree
        List<ZtreeData> ztreeDatas = new ArrayList<ZtreeData>();
        SerializeConfig config = new SerializeConfig();
        config.propertyNamingStrategy = PropertyNamingStrategy.CamelCase;
        for (Quanxian quanxian:list){
            //遍历权限将权限添加到ztree中
            ZtreeData ztreeData = new ZtreeData(quanxian.getTitle(),false,quanxian.getId(),true,quanxian.getpId());
            for (Jsqx p:pid){
                //遍历用户的权限，如果角色的权限和所有权限有想等的则将checked设置为true
                if (ztreeData.getId()==p.getPerid()){
                    ztreeData = new ZtreeData(quanxian.getTitle(),true,quanxian.getId(),true,quanxian.getpId());
                    break;
                }
            }
            ztreeDatas.add(ztreeData);
        }
        resp.getWriter().write(JSON.toJSONString(ztreeDatas));


    }
    public void juseqx(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
        resp.setContentType("text/json;charset=UTF-8");
        int rid = Integer.parseInt(req.getParameter("rid"));
        String pids = req.getParameter("pids");
        String[] pes = pids.split(",");
        List<Jsqx> list = new ArrayList<Jsqx>();
        Jsqx jsqx = null;
        for (String p:pes){
            int ps = Integer.parseInt(p);
            jsqx = new Jsqx(rid,ps);
            list.add(jsqx);
        }
        iQuanxianService.gouxuan(rid);
        try {
            for (Jsqx l:list){
                if (l!=null){
                    iQuanxianService.juseqx(l);
                }else{
                    break;
                }
            }
            resp.getWriter().write("{\"message\":\"设置成功\"}");
        } catch (NewsException e) {
            e.printStackTrace();
        }
    }
}
