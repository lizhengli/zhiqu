package com.lianyi.controller;

import com.lianyi.bean.GuoLv;
import com.lianyi.bean.Rizhi;
import com.lianyi.service.IGuolvService;
import com.lianyi.service.IjuSeService;
import com.lianyi.service.impl.GuolvServliceimpl;
import com.lianyi.service.impl.JuseServiceimpl;

import javax.servlet.*;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

/**
 * Created by dell on 2017/7/4.
 */
public class FirstFilter implements Filter {
    IGuolvService iGuolvService = new GuolvServliceimpl();
    IjuSeService ijuSeService  = new JuseServiceimpl();
    @Override
    public void init(FilterConfig filterConfig) throws ServletException {

    }

    @Override
    public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain) throws IOException, ServletException {
        HttpServletRequest request = (HttpServletRequest) req;
        HttpServletResponse response = (HttpServletResponse) res;
        //用户标识
        String biaoshi = request.getHeader("user-agent");
        //用户IP
        String ip = request.getRemoteAddr();
//        String url = request.getRequestURI().toString();
        int id =0;
        String user = "";
        Cookie[] cookies = request.getCookies();
        for(Cookie c :cookies ){
            //用户名
            if (c.getName().equals("username")){
                user = c.getValue();
            }
            if(c.getName().equals("id")){
                //用户id
                id = Integer.parseInt(c.getValue());
            }
        }
        //路径
        String panduan = request.getRequestURI().toString();
        //请求类型
        String qtype = request.getMethod();

       GuoLv guoLv= iGuolvService.roleid(id);
       List<GuoLv> list = iGuolvService.getUrl(guoLv.getRoleid());
        Boolean flag = false;
        String  caozuo = "";

        for (GuoLv l:list){
            if (panduan.equals(l.getUrl())){
                flag=true;
                break;
            }else{
                flag=false;
            }
        }
        if (panduan.equals("/type/yonghu.jsp")){
            if (flag==false){
                caozuo="用户管理(被阻)";
            }else if (flag==true){
                caozuo ="用户管理";
            }
        }else if (panduan.equals("/zhiqu/juseguanli.jsp")){
            if (flag==false){
                caozuo="角色管理(被阻)";
            }else if (flag==true){
                caozuo="角色管理";
            }
        }else if(panduan.equals("/TypeServlet")){
            if (flag==false){
                caozuo = "类型管理(被阻)";
            }else if (flag==true){
                caozuo = "类型管理";
            }
        }else if (panduan.equals("/zhiqu/quanxian.jsp")){
            if (flag==false){
                caozuo = "权限管理(被阻)";
            }else if (flag==true){
                caozuo = "权限管理";
            }
        }else if (panduan.equals("/zhiqu/newshoutai.jsp")){
            if (flag==false){
                caozuo = "新闻管理(被阻)";
            }else if (flag==true){
                caozuo = "新闻管理";
            }
        }else if (panduan.equals("/zhiqu/rizhi.jsp")){
            if (flag==true){
                caozuo = "日志记录";
            }else if (flag==false){
                caozuo = "日志记录(被阻)";
            }
        }
        if (flag==true){
            chain.doFilter(request, response);
        }else {
            response.sendRedirect(request.getContextPath()+"/zhiqu/usersPower.jsp");
        }
        //请求时间
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date d = new Date();
        String date = sdf.format(d);
        Rizhi rizhi = new Rizhi(caozuo,user,date,panduan,qtype,ip,biaoshi);
        iGuolvService.addRizhi(rizhi);


    }

    @Override
    public void destroy() {

    }
}
