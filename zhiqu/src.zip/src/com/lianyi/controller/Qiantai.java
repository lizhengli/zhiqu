package com.lianyi.controller;

import MyException.AdminUserException;
import MyException.AdminUserPasswordException;
import com.alibaba.fastjson.JSON;
import com.lianyi.bean.AdminUser;
import com.lianyi.bean.Message;
import com.lianyi.bean.ZhiQuUser;
import com.lianyi.service.IAdminUserService;
import com.lianyi.service.impl.AdminUserServiceimpl;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Created by dell on 2017/7/3.
 */
public class Qiantai extends HttpServlet {

    private IAdminUserService iAdminUserService = new AdminUserServiceimpl();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("text/json;charset=UTF-8");
        Cookie cookie = new Cookie("username1","");
        cookie.setMaxAge(0);
        cookie.setPath("/");
        Cookie cookie2 = new Cookie("qid","");
        cookie2.setMaxAge(0);
        cookie2.setPath("/");
        resp.addCookie(cookie);
        resp.addCookie(cookie2);
        resp.getWriter().write("再见");
    }

    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String username = req.getParameter("username");
        System.out.println(username);
        String password = req.getParameter("password");
        System.out.println(password);
        AdminUser adminUser = new AdminUser(username,password);
        Message message = new Message();
        message.status = 0;
        try {
           adminUser = iAdminUserService.LoginCheck(adminUser);
        } catch (AdminUserException e) {
            message.status = 1;
            message.message = e.getMessage();
            e.printStackTrace();
        } catch (AdminUserPasswordException e) {
            message.status = 2;
            message.message = e.getMessage();
            e.printStackTrace();
        }
        if (adminUser.getStatus() == 1) {
            //表示已经封禁
            message.status = 3;
            message.message = "用户已经被封禁";
        }
        if (adminUser.getStatus() == 2) {
            //申诉中
            message.status = 4;
            message.message = "申诉中";
        }
        Cookie cookie = new Cookie("username1", adminUser.getName());
        cookie.setMaxAge(12 * 60 * 60);
        cookie.setPath("/");
        Cookie cookie2 = new Cookie("qid", adminUser.getId()+"");
        cookie2.setMaxAge(12 * 60 * 60);
        cookie2.setPath("/");
        resp.addCookie(cookie);
        resp.addCookie(cookie2);

        resp.setContentType("text/json;charset=UTF-8");
        String reb = JSON.toJSONString(message);
        resp.getWriter().write(reb);
    }
    public void logout(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
        this.getServletConfig().getServletContext().getRequestDispatcher("/Users/denglu.jsp").forward(req,resp);
    }

}
