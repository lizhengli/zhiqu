package com.lianyi.controller;

import com.alibaba.fastjson.JSON;
import com.lianyi.Factory.BeanFactory;
import com.lianyi.bean.Quanxian;
import com.lianyi.exception.NewsException;
import com.lianyi.service.IQuanxianService;
import com.lianyi.service.impl.QuanxianServiceimpl;
import org.apache.commons.beanutils.BeanUtils;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Created by dell on 2017/7/6.
 */
public class QuanXian extends HttpServlet{
  IQuanxianService iQuanxianService = new QuanxianServiceimpl();
//    IQuanxianService iQuanxianService = BeanFactory.getInstance("quanxianService",IQuanxianService.class);
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req,resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String method = req.getParameter("m");
        if(method.equals("quanxian")){
            getQuanxian(req, resp);
        }else if (method.equals("dq")){
            dQuan(req, resp);
        }else if (method.equals("aq")){
            addQuan(req, resp);
        }else if(method.equals("sq")){
            sq(req, resp);
        }else if (method.equals("uqx")){
            uqx(req, resp);
        }
    }
    public void getQuanxian(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
        resp.setContentType("text/json;charset=UTF-8");
        List<Quanxian> list = new ArrayList<Quanxian>();
        list = iQuanxianService.getQuanxian();
        String json = JSON.toJSONString(list);
        resp.getWriter().write(json);

    }
    public void sq(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
        resp.setContentType("text/json;charset=UTF-8");
        Quanxian quanxian = null;
        int id = Integer.parseInt(req.getParameter("id"));
        try {
           quanxian =  iQuanxianService.select(id);
        } catch (NewsException e) {
            e.printStackTrace();
        }
        req.setAttribute("quanxian",quanxian);
        this.getServletConfig().getServletContext().getRequestDispatcher("/zhiqu/selectqx.jsp").forward(req,resp);
    }
    public void addQuan(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
        resp.setContentType("text/json;charset=UTF-8");
        String title = req.getParameter("title");
        String url = req.getParameter("url");
        String q_type = req.getParameter("q_type");
        int status = Integer.parseInt(req.getParameter("status"));
        int pid = Integer.parseInt(req.getParameter("pid"));
        try {
            iQuanxianService.addQuan(title,q_type,url,status,pid);
            resp.getWriter().write("{\"message\":\"添加成功\"}");
        } catch (NewsException e) {
            resp.getWriter().write(e.getMessage());
        }
    }
    public void uqx(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
        resp.setContentType("text/json;charset=UTF-8");
        Map map = req.getParameterMap();
        String title = req.getParameter("title");
        String url = req.getParameter("url");
        String q_type = req.getParameter("q_type");
        int status = Integer.parseInt(req.getParameter("status"));
        int id = Integer.parseInt(req.getParameter("id"));

        Quanxian quanxian = new Quanxian(id,title,q_type,url,status);
        try {
            iQuanxianService.uqx(quanxian);
            resp.getWriter().write("{\"message\":\"修改成功\"}");
        } catch (NewsException e) {
            resp.getWriter().write(e.getMessage());
        }
    }
    public void dQuan(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
        resp.setContentType("text/json;charset=UTF-8");
        int id = Integer.parseInt(req.getParameter("id"));
        try {
            iQuanxianService.deleteQuan(id);
            resp.getWriter().write("{\"message\":\"删除成功\"}");
        } catch (NewsException e) {
            resp.getWriter().write(e.getMessage());
        }
    }
}
