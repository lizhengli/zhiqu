package com.lianyi.controller;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

/**
 * Created by dell on 2017/7/3.
 */
public class YanZhengMa extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String vcode = req.getParameter("vcode");
        HttpSession session = req.getSession(true);
        String sessioncode = (String) session.getAttribute("vcode");
        System.out.println("用户提交"+vcode.toUpperCase()+"------sessioncode="+sessioncode);
        String vode = vcode.toUpperCase();
        if(vode.equals(sessioncode)){
            resp.setContentType("text/json;charset=UTF-8");
            resp.getWriter().write("{\"message\":\"验证码正确\"}");
        }else{
            resp.setContentType("text/json;charset=UTF-8");
            resp.getWriter().write("{\"message\":\"验证码错误\"}");
        }
    }
}
