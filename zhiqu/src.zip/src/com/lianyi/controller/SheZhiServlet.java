package com.lianyi.controller;

import com.lianyi.bean.JueSe;
import com.lianyi.service.IYonghuService;
import com.lianyi.service.impl.Yonghuimpl;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

/**
 * Created by dell on 2017/7/12.
 */
public class SheZhiServlet extends HttpServlet {
    IYonghuService iYonghuService = new Yonghuimpl();
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        List<JueSe> list = iYonghuService.getJuse();
        resp.setContentType("text/json;charset=UTF-8");
        req.setAttribute("juse",list);
        this.getServletConfig().getServletContext().getRequestDispatcher("/type/yonghu.jsp").forward(req,resp);

    }
}
