package com.lianyi.controller;

import com.alibaba.fastjson.JSON;
import com.lianyi.bean.NewsBean;
import com.lianyi.bean.NewsTypeBean;
import com.lianyi.exception.NewsException;
import com.lianyi.service.INewsService;
import com.lianyi.service.impl.NewsServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

/**
 * Created by dell on 2017/7/3.
 */
public class NewServlet extends HttpServlet {
    INewsService iNewsService = new NewsServiceImpl();
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req,resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String method = req.getParameter("m");
        if(method.equals("yule")){
            yule(req,resp);
        }else if(method.equals("neirong")){
            neirong(req, resp);
        }
        else if (method.equals("xianshi")){
            xianshi(req, resp);
        }else if(method.equals("add")){
            addNew(req, resp);
        }else if(method.equals("delete")){
            delete(req, resp);
        }else if (method.equals("select")){
            select(req, resp);
        }else if (method.equals("update")){
            update(req, resp);
        }
    }
    public void select(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
        resp.setContentType("text/html; charset=UTF-8");
        String id = req.getParameter("id");
        NewsBean newsBean = new NewsBean();
        if(id!=null){
            try {
                newsBean = iNewsService.getNew(Integer.parseInt(id));
            } catch (NewsException e) {
                e.printStackTrace();
            }
        }else {
            newsBean.setTypeID(0);
            newsBean.setContent("");
            newsBean.setTitle("");
        }
        List<NewsTypeBean> list = iNewsService.getNewsTypeALL();
        req.setAttribute("newsType",list);
        req.setAttribute("new1",newsBean);
        this.getServletConfig().getServletContext().getRequestDispatcher("/zhiqu/xiugai.jsp").forward(req,resp);
    }
    public void update(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
        resp.setContentType("text/html; charset=UTF-8");
        int id = Integer.parseInt(req.getParameter("id"));
        String title = req.getParameter("title");
        int typeID = Integer.parseInt(req.getParameter("typeID"));
        String content = req.getParameter("content");
        NewsBean newsBean = new NewsBean(title,content,typeID);
        try {
            iNewsService.updateNew(id,newsBean);
            resp.getWriter().write("修改成功");
        } catch (NewsException e) {
            resp.getWriter().write(e.getMessage());
        }

    }
    public void delete(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
        int id = Integer.parseInt(req.getParameter("id"));
        try {
            iNewsService.deleteNew(id);
            resp.setContentType("text/json;charset=UTF-8");
            resp.getWriter().write("删除成功");
        } catch (NewsException e) {
            resp.getWriter().write(e.getMessage());
        }
    }
    public void  addNew(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
            String title = req.getParameter("title");
            String content = req.getParameter("neirong");
            int type_id = Integer.parseInt(req.getParameter("type_id"));
            NewsBean newsBean = new NewsBean(title,content,type_id);

        try {
            iNewsService.addNew(newsBean);
            resp.setContentType("text/json;charset=UTF-8");
            resp.getWriter().write("发布成功");
        } catch (NewsException e) {
            resp.getWriter().write(e.getMessage());
        }
    }
    public void xianshi(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
        List<NewsBean> newList = iNewsService.getNewsAll();
        String json = JSON.toJSONString(newList);
        resp.setContentType("text/json;charset=UTF-8");
        resp.getWriter().write(json);
    }
    public void yule(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("text/html;charset=UTF-8");
        List<NewsBean> list = iNewsService.getNewsAll();
        req.setAttribute("newsAll",list);
        this.getServletConfig().getServletContext().getRequestDispatcher("/Users/News.jsp").forward(req,resp);

    }
    public void neirong(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
        resp.setContentType("text/html; charset=UTF-8");
        int id = Integer.parseInt(req.getParameter("id"));
        NewsBean newsBean = null;
        try {
            newsBean = iNewsService.getNew(id);
            req.setAttribute("new1",newsBean);
        } catch (NewsException e) {
            e.printStackTrace();
        }
        String content = newsBean.getContent();
        String[] str = content.split("\n");
        String sc = "";
        for(String s:str){
            sc+="<p>"+s+"</p>";
        }
        newsBean.setContent(sc);
        this.getServletConfig().getServletContext().getRequestDispatcher("/Users/neirong.jsp").forward(req,resp);
    }
}
