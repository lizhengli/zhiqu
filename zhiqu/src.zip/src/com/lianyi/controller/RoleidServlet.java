package com.lianyi.controller;

import com.alibaba.fastjson.JSON;
import com.lianyi.bean.JueSe;
import com.lianyi.bean.Rizhi;
import com.lianyi.exception.NewsException;
import com.lianyi.service.IjuSeService;
import com.lianyi.service.impl.JuseServiceimpl;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

/**
 * Created by dell on 2017/7/7.
 */
public class RoleidServlet extends HttpServlet {
    IjuSeService ijuse = new JuseServiceimpl();
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String method = req.getParameter("m");
        if("getAll".equals(method)){
            getAll(req,resp);
        }else if("delete".equals(method)){
            delete(req,resp);
        }else if("select".equals(method)){
            select(req,resp);
        }else if (method.equals("add")){
            addJuse(req, resp);
        }else if (method.equals("update")){
            update(req, resp);
        }else if(method.equals("getRizhi")){
            getRizhi(req, resp);
        }
    }

    public void getAll(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
        List<JueSe> list = ijuse.getAll();
        String json = JSON.toJSONString(list);
        resp.setContentType("text/json;charset=UTF-8");
        resp.getWriter().write(json);
    }
    public void delete (HttpServletRequest req, HttpServletResponse resp)throws ServletException, IOException {
        resp.setContentType("text/json;charset=UTF-8");
        int id = Integer.parseInt(req.getParameter("id"));
        try {
            ijuse.delete(id);
            resp.getWriter().write("{\"message\":\"删除成功\"}");
        } catch (NewsException e) {
            resp.getWriter().write(e.getMessage());
        }
    }
    public void addJuse(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
        resp.setContentType("text/json;charset=UTF-8");
        String title = req.getParameter("title");
        String jsdesc = req.getParameter("jsdesc");
        JueSe juese = new JueSe(title,jsdesc);
        try {
            ijuse.addJuse(juese);
            resp.getWriter().write("{\"message\":\"添加成功\"}");
        } catch (NewsException e) {
            resp.getWriter().write(e.getMessage());
        }
    }
    public void update(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
        resp.setContentType("text/json;charset=UTF-8");
        int id = Integer.parseInt(req.getParameter("id"));
        String title = req.getParameter("title");
        String jsdesc = req.getParameter("jsdesc");
        JueSe juese = new JueSe(title,jsdesc,id);
//        juese.setId(id);
//        juese.setTitle(title);
//        juese.setJsdesc(jsdesc);
        try {
            ijuse.update(juese);
            resp.getWriter().write("{\"message\":\"修改成功\"}");
        } catch (NewsException e) {
            resp.getWriter().write(e.getMessage());
        }
    }
    public void select(HttpServletRequest req, HttpServletResponse resp)throws ServletException, IOException{
        JueSe juese = null;
        int id = Integer.parseInt(req.getParameter("id"));
        try {
          juese =   ijuse.select(id);
        } catch (NewsException e) {
            e.printStackTrace();
        }
        req.setAttribute("juese",juese);
        this.getServletConfig().getServletContext().getRequestDispatcher("/zhiqu/upjuse.jsp").forward(req,resp);


    }
    public void getRizhi(HttpServletRequest req, HttpServletResponse resp)throws ServletException, IOException{
        List<Rizhi> list = ijuse.getRizhi();
        String json = JSON.toJSONString(list);
        resp.setContentType("text/json;charset=UTF-8");
        resp.getWriter().write(json);

    }
}
