package com.lianyi.controller;

import com.alibaba.fastjson.JSON;
import com.lianyi.bean.Gongying;
import com.lianyi.service.IzhiquService;
import com.lianyi.service.impl.ZhiquServiceimpl;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by dell on 2017/7/4.
 */
public class GongyingServlet extends HttpServlet {
    IzhiquService izhiquService = new ZhiquServiceimpl();
    List<Gongying> list = new ArrayList<Gongying>();
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
            String method = req.getParameter("m");
            if(method.equals("gongying")){
                gongying(req, resp);
            }else if (method.equals("xianshi")){
                xianshi(req, resp);
            }else {

            }
    }
    public void xianshi(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
        resp.setContentType("text/html;charset=UTF-8");
        int id = Integer.parseInt(req.getParameter("pid"));
        list = izhiquService.xianshi(id);
        String json = JSON.toJSONString(list);
        resp.getWriter().write(json);

    }
    public void gongying(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
        list  = izhiquService.gongying(0);
        req.setAttribute("gongying",list);
        this.getServletConfig().getServletContext().getRequestDispatcher("/zhiqu/zhuyeinfo.jsp").forward(req,resp);
    }

}
