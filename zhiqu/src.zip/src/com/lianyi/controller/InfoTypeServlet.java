package com.lianyi.controller;

import com.lianyi.bean.FabuRen;
import com.lianyi.bean.InfoType;
import com.lianyi.bean.NewsBean;
import com.lianyi.bean.info;
import com.lianyi.service.IinfoService;
import com.lianyi.service.impl.IinfoTypeService;
import com.lianyi.service.impl.InfoServiceimpl;
import com.lianyi.service.impl.InfoTypeServiceimpl;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by dell on 2017/7/16.
 */
public class InfoTypeServlet extends HttpServlet {
    IinfoTypeService iinfoTypeService = new InfoTypeServiceimpl();
    IinfoService iinfoService = new InfoServiceimpl();
    info ifo = new info();
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req,resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String method = req.getParameter("m");
        if (method.equals("ftype")||method.equals("ftype2")){
            ftype(req, resp);
        }else if (method.equals("stype")){
            stype(req, resp);
        }else if (method.equals("infoftype")||method.equals("infostype")){
            infotype(req, resp);
        }else if (method.equals("allftype")||method.equals("allstype")){
            allinfo(req, resp);
        }else if (method.equals("getinfo")){
            getinfo(req, resp);
        }else if (method.equals("sousuo")){
            sousuo(req, resp);
        }
    }
    public void ftype(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
        String m =req.getParameter("m");
        List<InfoType> list = new ArrayList<InfoType>();
        list = iinfoTypeService.ftype();
        req.setAttribute("ftype",list);
//        resp.setContentType("text/html;charset=utf-8");
        if (m.equals("ftype")){
            this.getServletConfig().getServletContext().getRequestDispatcher("/utf8-jsp/demo.jsp").forward(req,resp);
        }else if (m.equals("ftype2")){
            this.getServletConfig().getServletContext().getRequestDispatcher("/utf8-jsp/demo2.jsp").forward(req,resp);
        }

    }
    public void stype(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
        int pid = Integer.parseInt(req.getParameter("pid"));
        System.out.println(pid);
        List<InfoType> list = iinfoTypeService.stype(pid);
        String str = "<option value=\"\">-请选择-</option>";
        for (InfoType l:list){
            String option = "<option value=\""+l.getId()+"\">"+l.getName()+"</option>";
            str+=option;
        }
        resp.setContentType("text/html;charset=utf-8");
        PrintWriter out = resp.getWriter();
        out.println(str);
        out.flush();
        out.close();
    }
    public void infotype(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
        List<info> list = new ArrayList<info>();
        String m = req.getParameter("m");
        if (m.equals("infoftype")){
            int ftype = Integer.parseInt(req.getParameter("pid"));
            list = iinfoTypeService.infoftype(ftype);
            req.setAttribute("infoall",list);
            this.getServletConfig().getServletContext().getRequestDispatcher("/zhiqu/allinfo.jsp").forward(req,resp);

        }else  if (m.equals("infostype")){
            int stype = Integer.parseInt(req.getParameter("sid"));
            list =  iinfoTypeService.infostype(stype);
            req.setAttribute("infoall",list);
            this.getServletConfig().getServletContext().getRequestDispatcher("/zhiqu/allinfo.jsp").forward(req,resp);
        }

    }
    public void  allinfo(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{

        info ifo = new info();
        String m = req.getParameter("m");
        if (m.equals("allftype")){
            int id = Integer.parseInt(req.getParameter("ftype"));
            ifo = iinfoService.allinfoftype(id);
            req.setAttribute("infoall",ifo);
            this.getServletConfig().getServletContext().getRequestDispatcher("/zhiqu/allinfo.jsp").forward(req,resp);
        }else if (m.equals("allstype")){
            int id = Integer.parseInt(req.getParameter("stype"));
            ifo = iinfoService.allinfostype(id);
            req.setAttribute("infoall",ifo);
            this.getServletConfig().getServletContext().getRequestDispatcher("/zhiqu/allinfo.jsp").forward(req,resp);
        }
    }
    public void getinfo(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
        FabuRen fabuRen = new FabuRen();
        String title = req.getParameter("title");
        int uid = Integer.parseInt(req.getParameter("uid"));
        fabuRen = iinfoTypeService.getftypeinfo(uid,title);
        req.setAttribute("fbr",fabuRen);
        this.getServletConfig().getServletContext().getRequestDispatcher("/zhiqu/infocontent.jsp").forward(req,resp);
    }
    public void sousuo(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
        String n = req.getParameter("neirong");
        String soutype = req.getParameter("soutype");
        if (soutype.equals("news")){
            List<NewsBean> list = new ArrayList<NewsBean>();
            list = iinfoTypeService.sounews(n);
            req.setAttribute("newsAll",list);
            this.getServletConfig().getServletContext().getRequestDispatcher("/Users/News.jsp").forward(req,resp);
        }else if (soutype.equals("gongying")){
            List<info> list = new ArrayList<info>();
            list = iinfoTypeService.souinfo(n);
            req.setAttribute("allinfo",list);
            this.getServletConfig().getServletContext().getRequestDispatcher("/zhiqu/sousuo.jsp").forward(req,resp);
        }
    }
}
