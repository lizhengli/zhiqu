package com.lianyi.controller;

import com.lianyi.bean.User;
import com.lianyi.service.IUserService;
import com.lianyi.service.impl.UserServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

/**
 * Created by Lenovo on 2017/6/16.
 */
public class UserServlet extends HttpServlet {
    IUserService iUserService = new UserServiceImpl();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        List<User> users = iUserService.getUsers();
        req.setAttribute("users",users);
        this.getServletConfig().getServletContext().getRequestDispatcher("/Users/index.jsp").forward(req,resp);
    }
}
