package com.lianyi.controller;

import com.alibaba.fastjson.JSON;
import com.lianyi.Factory.BeanFactory;
import com.lianyi.bean.HuiHuaBean;
import com.lianyi.service.IHuiHuaService;
import com.lianyi.service.impl.HuiHuaServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

/**
 * Created by Lenovo on 2017/7/17.
 */
public class HuiHuaManageServlet extends HttpServlet {
    IHuiHuaService iHuiHuaService = new HuiHuaServiceImpl();

    public HuiHuaManageServlet() throws IllegalAccessException, InstantiationException, ClassNotFoundException {
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req,resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String m = req.getParameter("m");
        if("all".equals(m)){//全部
            all(req,resp);
        }else if("delete".equals(m)){//强制下线
            delete(req,resp);
        }else if("update".equals(m)){//修改备注
            update(req,resp);
        }else if("updateSave".equals(m)){//保存修改
            updateSave(req,resp);
        }else if("add".equals(m)){//新增
            add(req,resp);
        }else{
            index(req,resp);
        }
    }

    protected void all(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        List<HuiHuaBean> list = iHuiHuaService.findAll();
        String json = JSON.toJSONString(list);
        resp.setContentType("text/json;charset=utf-8");
        resp.getWriter().write(json);
    }

    protected void delete(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Integer id = Integer.parseInt(req.getParameter("id"));
        HuiHuaBean huiHua = iHuiHuaService.findById(id);
        OnlineNumberListener.deleteSession(huiHua.getSessionID());
        resp.getWriter().write("对方已被强制下线！");
    }

    protected void update(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

    }

    protected void updateSave(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        int id = Integer.parseInt(req.getParameter("id"));
        String name = req.getParameter("name");
        iHuiHuaService.update(id,name);
        resp.setContentType("text/html; charset=utf-8");
        resp.getWriter().write("修改成功!");
    }

    protected void add(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

    }
    public  void index(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
        this.getServletConfig().getServletContext().getRequestDispatcher("/huihua/dialogue_manage.jsp").forward(req,resp);
    }
}
