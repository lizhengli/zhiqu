package com.lianyi.controller;

import com.alibaba.fastjson.JSON;
import com.lianyi.Factory.BeanFactory;
import com.lianyi.bean.Type;
import com.lianyi.dao.ZtreeQuanxian;
import com.lianyi.service.ITypeService;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

/**
 * Created by Lenovo on 2017/6/26.
 */
public class TypeServlet extends HttpServlet{
    ITypeService itypeService = BeanFactory.getInstance("typeService",ITypeService.class);
    public TypeServlet() throws IllegalAccessException, InstantiationException, ClassNotFoundException {
    }


    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req,resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String method = req.getParameter("m");
        if("add".equals(method)){
            add(req,resp);
        }else if("update".equals(method)){
            update(req,resp);
        }else if("ajax_all".equals(method)){
            ajaxAll(req,resp);
        }else if("delete".equals(method)){
            delete(req,resp);
        }else if("getbyid".equals(method)){
            getById(req,resp);
        }else{
            index(req,resp);
        }
    }



    public void index(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        List<Type> typeList = itypeService.getAll();
        req.setAttribute("types",typeList);
        this.getServletConfig().getServletContext().getRequestDispatcher("/type/index.jsp").forward(req,resp);
    }

    public void add(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Type type = new Type();
        type.setTitle(req.getParameter("title"));
        type.setDescription(req.getParameter("description"));
        type.setPid(Integer.parseInt(req.getParameter("pid")));
        itypeService.addType(type);
        resp.setContentType("text/json;charset=UTF-8");
        resp.getWriter().write("{\"message\":\"添加成功\"}");
    }

    public void ajaxAll(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        List<Type> typeList = itypeService.getAll();
        String json = JSON.toJSONString(typeList);
        resp.setContentType("text/json;charset=UTF-8");
        resp.getWriter().write(json);
    }

    public void delete(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        itypeService.deleteType(Integer.parseInt(req.getParameter("id")));
        resp.setContentType("text/json;charset=UTF-8");
        resp.getWriter().write("{\"message\":\"删除成功\"}");
    }

    public void update(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        int id = Integer.parseInt(req.getParameter("id"));
        String title = req.getParameter("title");
        String desc = req.getParameter("description");
        int pid = Integer.parseInt(req.getParameter("pid"));
        Type type = new Type();
        type.setPid(pid);
        type.setId(id);
        type.setTitle(title);
        type.setDescription(desc);
        itypeService.update(type);
        resp.setContentType("text/json;charset=UTF-8");
        resp.getWriter().write("{\"message\":\"更新成功\"}");
    }

    public void getById(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        int id = Integer.parseInt(req.getParameter("id"));
        Type type = itypeService.getTypeById(id);
        req.setAttribute("type",type);
        List<Type> typeList = itypeService.getAll();
        req.setAttribute("types",typeList);
        this.getServletConfig().getServletContext().getRequestDispatcher("/type/update.jsp").forward(req,resp);
    }
}
