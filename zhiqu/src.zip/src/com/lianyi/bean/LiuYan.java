package com.lianyi.bean;

import java.sql.Timestamp;

/**
 * Created by dell on 2017/7/14.
 */
public class LiuYan {
    private int id;
    private String lxr;
    private String tel;
    private String address;
    private String content;
    private String title;
    private int uid;
    private String faburen;
    private Timestamp ctime;
    private int status;
    private int read;

    public LiuYan(int id, String lxr, String tel, String address, String content,String title,int uid,String faburen,Timestamp ctime,int status,int read) {
        this.id = id;
        this.lxr = lxr;
        this.tel = tel;
        this.address = address;
        this.content = content;
        this.title= title;
        this.uid = uid;
        this.faburen=faburen;
        this.ctime = ctime;
        this.status = status;
        this.read=read;
    }

    public LiuYan(int id, int status) {
        this.id = id;
        this.status = status;
    }

    public LiuYan(String lxr, String tel, String address, String content, String title, int uid, String faburen) {
        this.lxr = lxr;
        this.tel = tel;
        this.address = address;
        this.content = content;
        this.title= title;
        this.uid = uid;
        this.faburen=faburen;
    }

    public LiuYan() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getLxr() {
        return lxr;
    }

    public void setLxr(String lxr) {
        this.lxr = lxr;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getUid() {
        return uid;
    }

    public void setUid(int uid) {
        this.uid = uid;
    }

    public String getFaburen() {
        return faburen;
    }

    public void setFaburen(String faburen) {
        this.faburen = faburen;
    }

    public Timestamp getCtime() {
        return ctime;
    }

    public void setCtime(Timestamp ctime) {
        this.ctime = ctime;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public int getRead() {
        return read;
    }

    public void setRead(int read) {
        this.read = read;
    }
}
