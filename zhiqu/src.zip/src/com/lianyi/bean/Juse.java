package com.lianyi.bean;

import java.sql.Timestamp;

/**
 * Created by dell on 2017/7/7.
 */
public class Juse {
    private int id;
    private String username;
    private String password;
    private String jusetitle;
    private String juesedesc;
    private Timestamp ctime;

    public Juse() {
    }

    public Juse(int id, String username, String jusetitle, String juesedesc, Timestamp ctime) {
        this.id = id;
        this.username = username;

        this.jusetitle = jusetitle;
        this.juesedesc = juesedesc;
        this.ctime = ctime;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Juse(String username, String password, String jusetitle, String juesedesc) {
        this.username = username;
        this.password = password;
        this.jusetitle = jusetitle;
        this.juesedesc = juesedesc;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getJusetitle() {
        return jusetitle;
    }

    public void setJusetitle(String jusetitle) {
        this.jusetitle = jusetitle;
    }

    public String getJuesedesc() {
        return juesedesc;
    }

    public void setJuesedesc(String juesedesc) {
        this.juesedesc = juesedesc;
    }

    public Timestamp getCtime() {
        return ctime;
    }

    public void setCtime(Timestamp ctime) {
        this.ctime = ctime;
    }
}
