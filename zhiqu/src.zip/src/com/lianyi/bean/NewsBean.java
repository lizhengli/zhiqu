package com.lianyi.bean;

import java.sql.Date;

public class NewsBean {
    private int id;//编号
    private String title;//新闻标题
    private String content;//新闻内容
    private Date date;//发布时间
    private int typeID;//新闻类型
    private String newType;

    public NewsBean() {
    }
    public NewsBean(String title, String content, int typeID) {
        this.title = title;
        this.content = content;
        this.typeID = typeID;
    }

    public NewsBean(int id, String title, String content, Date date, int typeID, String newType) {
        this.id = id;
        this.title = title;
        this.content = content;
        this.date = date;
        this.typeID = typeID;
        this.newType = newType;
    }

    @Override
    public String toString() {
        return "NewsBean{" + "id=" + id + ", title='" + title + '\'' + ", content='" + content + '\'' + ", date=" + date + ", typeID=" + typeID + '}';
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public int getTypeID() {
        return typeID;
    }

    public void setTypeID(int typeID) {
        this.typeID = typeID;
    }

    public String getNewType() {
        return newType;
    }

    public void setNewType(String newType) {
        this.newType = newType;
    }
}
