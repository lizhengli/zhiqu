package com.lianyi.bean;

/**
 * Created by dell on 2017/7/12.
 */
public class Jsyh {
    private int userid;
    private String title;

    public Jsyh() {
    }

    public Jsyh(int userid, String title) {
        this.userid = userid;
        this.title = title;
    }

    public int getUserid() {
        return userid;
    }

    public void setUserid(int userid) {
        this.userid = userid;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}
