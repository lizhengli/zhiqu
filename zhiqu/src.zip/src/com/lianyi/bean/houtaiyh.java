package com.lianyi.bean;

import java.sql.Timestamp;

/**
 * Created by dell on 2017/7/6.
 */
public class houtaiyh {
    private int id;
    private String username;
    private String title;
    private Timestamp ctime;

    public houtaiyh(int id, String username, String title, Timestamp ctime) {
        this.id = id;
        this.username = username;
        this.title = title;
        this.ctime = ctime;
    }

    public houtaiyh() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Timestamp getCtime() {
        return ctime;
    }

    public void setCtime(Timestamp ctime) {
        this.ctime = ctime;
    }
}
