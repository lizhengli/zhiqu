package com.lianyi.bean;

/**
 * Created by dell on 2017/6/30.
 */
public class Sheng {
    private String code;
    private String name;

    public Sheng(String code, String name) {
        this.code = code;
        this.name = name;
    }

    public Sheng() {
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
