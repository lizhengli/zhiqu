package com.lianyi.bean;

/**
 * Created by dell on 2017/7/19.
 */
public class PageCount {
    private int pagenumber;

    public PageCount(int pagenumber) {
        this.pagenumber = pagenumber;
    }

    public PageCount() {
    }

    public int getPagenumber() {
        return pagenumber;
    }

    public void setPagenumber(int pagenumber) {
        this.pagenumber = pagenumber;
    }
}
