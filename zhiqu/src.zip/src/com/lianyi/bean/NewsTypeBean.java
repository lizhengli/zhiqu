package com.lianyi.bean;

import java.sql.Date;

public class NewsTypeBean {
    private int id;//编号
    private String name;//类型名称
    private String description;//类型描述
    private Date date;//类型添加时间

    public NewsTypeBean() {
    }

    public NewsTypeBean(int id, String name, String description, Date date) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.date = date;
    }

    @Override
    public String toString() {
        return "NewsTypeBean{" + "id=" + id + ", name='" + name + '\'' + ", description='" + description + '\'' + ", date=" + date + '}';
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }
}
