package com.lianyi.bean;

/**
 * Created by dell on 2017/7/17.
 */
public class Gsxx {
    private int yhid2;
    private String gsname;
    private String lxr;
    private String sex;
    private String zw;
    private String sheng;
    private String city;
    private String address;
    private String  youbian;
    private String tel;
    private String chuanzhen;
    private String qq;
    private String msn;
    private String hangye;
    private String gslx;
    private String xingzhi;
    private String moshi;
    private String zczj;
    private String yineye;
    private String yuangong;
    private String zhuyao;
    private String jinchu;

    public Gsxx(int yhid2, String gsname, String lxr, String sex, String zw, String sheng, String city, String address, String youbian, String tel, String chuanzhen, String qq, String msn, String hangye, String gslx, String xingzhi, String moshi, String zczj, String yineye, String yuangong, String zhuyao, String jinchu) {
        this.yhid2 = yhid2;
        this.gsname = gsname;
        this.lxr = lxr;
        this.sex = sex;
        this.zw = zw;
        this.sheng = sheng;
        this.city = city;
        this.address = address;
        this.youbian = youbian;
        this.tel = tel;
        this.chuanzhen = chuanzhen;
        this.qq = qq;
        this.msn = msn;
        this.hangye = hangye;
        this.gslx = gslx;
        this.xingzhi = xingzhi;
        this.moshi = moshi;
        this.zczj = zczj;
        this.yineye = yineye;
        this.yuangong = yuangong;
        this.zhuyao = zhuyao;
        this.jinchu = jinchu;
    }

    public Gsxx() {
    }

    public int getYhid2() {
        return yhid2;
    }

    public void setYhid2(int yhid2) {
        this.yhid2 = yhid2;
    }

    public String getGsname() {
        return gsname;
    }

    public void setGsname(String gsname) {
        this.gsname = gsname;
    }

    public String getLxr() {
        return lxr;
    }

    public void setLxr(String lxr) {
        this.lxr = lxr;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getZw() {
        return zw;
    }

    public void setZw(String zw) {
        this.zw = zw;
    }

    public String getSheng() {
        return sheng;
    }

    public void setSheng(String sheng) {
        this.sheng = sheng;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getYoubian() {
        return youbian;
    }

    public void setYoubian(String youbian) {
        this.youbian = youbian;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public String getChuanzhen() {
        return chuanzhen;
    }

    public void setChuanzhen(String chuanzhen) {
        this.chuanzhen = chuanzhen;
    }

    public String getQq() {
        return qq;
    }

    public void setQq(String qq) {
        this.qq = qq;
    }

    public String getMsn() {
        return msn;
    }

    public void setMsn(String msn) {
        this.msn = msn;
    }

    public String getHangye() {
        return hangye;
    }

    public void setHangye(String hangye) {
        this.hangye = hangye;
    }

    public String getGslx() {
        return gslx;
    }

    public void setGslx(String gslx) {
        this.gslx = gslx;
    }

    public String getXingzhi() {
        return xingzhi;
    }

    public void setXingzhi(String xingzhi) {
        this.xingzhi = xingzhi;
    }

    public String getMoshi() {
        return moshi;
    }

    public void setMoshi(String moshi) {
        this.moshi = moshi;
    }

    public String getZczj() {
        return zczj;
    }

    public void setZczj(String zczj) {
        this.zczj = zczj;
    }

    public String getYineye() {
        return yineye;
    }

    public void setYineye(String yineye) {
        this.yineye = yineye;
    }

    public String getYuangong() {
        return yuangong;
    }

    public void setYuangong(String yuangong) {
        this.yuangong = yuangong;
    }

    public String getZhuyao() {
        return zhuyao;
    }

    public void setZhuyao(String zhuyao) {
        this.zhuyao = zhuyao;
    }

    public String getJinchu() {
        return jinchu;
    }

    public void setJinchu(String jinchu) {
        this.jinchu = jinchu;
    }
}
