package com.lianyi.bean;

import java.sql.Timestamp;

/**
 * Created by dell on 2017/7/3.
 */
public class news_type {
    private int id;
    private String name;
    private Timestamp data;

    public news_type(int id, String name, Timestamp data) {
        this.id = id;
        this.name = name;
        this.data = data;
    }

    public news_type() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Timestamp getData() {
        return data;
    }

    public void setData(Timestamp data) {
        this.data = data;
    }
}
