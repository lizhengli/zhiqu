package com.lianyi.bean;


import java.sql.Timestamp;
import java.util.Date;

/**
 * Created by Lenovo on 2017/6/26.
 */
public class Type {
    private int id;
    private String title;
    private String  ptitle;
    private int pid;
    private String description;
    private Timestamp createTime;

    public Type(int id, String title, String ptitle, String description, Timestamp createTime) {
        this.id = id;
        this.title = title;
        this.ptitle = ptitle;
        this.description = description;
        this.createTime = createTime;
    }

    public Type(int pid, String title, String description) {
        this.pid = pid;
        this.title = title;
        this.description = description;
    }

    public int getPid() {
        return pid;
    }

    public void setPid(int pid) {
        this.pid = pid;
    }

    public Type(){

    }
    public Timestamp getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Timestamp createTime) {
        this.createTime = createTime;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getPtitle() {
        return ptitle;
    }

    public void setPtitle(String ptitle) {
        this.ptitle = ptitle;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
