package com.lianyi.bean;

import java.sql.Timestamp;

/**
 * Created by dell on 2017/7/7.
 */
public class JueSe {
    private int id;
    private String title;
    private Timestamp ctime;
    private String jsdesc;

    public JueSe(int id, String title, Timestamp ctime, String jsdesc) {
        this.id = id;
        this.title = title;
        this.ctime = ctime;
        this.jsdesc = jsdesc;
    }

    public JueSe(String title, String jsdesc,int id) {
        this.title = title;
        this.jsdesc = jsdesc;
        this.id = id;
    }

    public JueSe(String title, String jsdesc) {
        this.title = title;
        this.jsdesc = jsdesc;
    }
    public JueSe() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Timestamp getCtime() {
        return ctime;
    }

    public void setCtime(Timestamp ctime) {
        this.ctime = ctime;
    }

    public String getJsdesc() {
        return jsdesc;
    }

    public void setJsdesc(String jsdesc) {
        this.jsdesc = jsdesc;
    }
}
