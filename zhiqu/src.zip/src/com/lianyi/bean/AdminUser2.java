package com.lianyi.bean;

import java.sql.Timestamp;

/**
 * Created by dell on 2017/7/4.
 */
public class AdminUser2 {
    private int id;
    private String username;
    private String password;
    private Timestamp ctime;
    private String loginip;
    private int status;

    public AdminUser2() {

    }

    public AdminUser2(String username, String password) {
        this.username = username;
        this.password = password;
    }

    public AdminUser2(int id, String username, String password,String loginip , Timestamp ctime, int status) {
        this.id = id;
        this.username = username;
        this.password = password;
        this.loginip = loginip;
        this.ctime = ctime;
        this.status = status;
    }

    public AdminUser2(String username, String password, int status,int id) {
        this.username = username;
        this.password = password;
        this.status = status;
        this.id = id;
    }
    public AdminUser2(String username, String password, int status) {
        this.username = username;
        this.password = password;
        this.status = status;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Timestamp getCtime() {
        return ctime;
    }

    public void setCtime(Timestamp ctime) {
        this.ctime = ctime;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getLoginip() {
        return loginip;
    }

    public void setLoginip(String loginip) {
        this.loginip = loginip;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }
}
