package com.lianyi.bean;

/**
 * Created by dell on 2017/7/13.
 */
public class Userinfo {
    private  String  username;
    private String password;
    private String gsname;
    private String address;
    private String swemail;
    private String phonenumber;

    public Userinfo() {
    }

    public Userinfo(String username, String password, String gsname, String swemail, String address, String phonenumber) {
        this.username = username;
        this.password = password;
        this.gsname = gsname;
        this.swemail = swemail;
        this.address = address;
        this.phonenumber = phonenumber;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getGsname() {
        return gsname;
    }

    public void setGsname(String gsname) {
        this.gsname = gsname;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getSwemail() {
        return swemail;
    }

    public void setSwemail(String swemail) {
        this.swemail = swemail;
    }

    public String getPhonenumber() {
        return phonenumber;
    }

    public void setPhonenumber(String phonenumber) {
        this.phonenumber = phonenumber;
    }
}
