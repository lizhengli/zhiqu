package com.lianyi.bean;

/**
 * Created by dell on 2017/6/30.
 */
public class Gsinfo {
    private String gongsi;
    private String lianxiren;
    private String xingbie;
    private String zhiwei;
    private String shengfen;
    private String  chengshi;
    private String  gongsidizhi;
    private String  youbian;
    private String  gudingdianhua;
    private String  chuanzhen;
    private String  qq;
    private String  msn;
    private String  suoshutype;
    private String  hangyedalei;
    private String  qiyexingzhi;
    private String jingyingmoshi;
    private String money;
    private String nianmoney;
    private String guyuan;
    private String zhuyingyewu;
    private String jinchukou;

    public Gsinfo(String gongsi, String lianxiren, String xingbie, String zhiwei, String shengfen, String chengshi, String gongsidizhi, String youbian, String gudingdianhua, String chuanzhen, String qq, String msn, String suoshutype, String hangyedalei, String qiyexingzhi, String jingyingmoshi, String money, String nianmoney, String guyuan, String zhuyingyewu, String jinchukou) {
        this.gongsi = gongsi;
        this.lianxiren = lianxiren;
        this.xingbie = xingbie;
        this.zhiwei = zhiwei;
        this.shengfen = shengfen;
        this.chengshi = chengshi;
        this.gongsidizhi = gongsidizhi;
        this.youbian = youbian;
        this.gudingdianhua = gudingdianhua;
        this.chuanzhen = chuanzhen;
        this.qq = qq;
        this.msn = msn;
        this.suoshutype = suoshutype;
        this.hangyedalei = hangyedalei;
        this.qiyexingzhi = qiyexingzhi;
        this.jingyingmoshi = jingyingmoshi;
        this.money = money;
        this.nianmoney = nianmoney;
        this.guyuan = guyuan;
        this.zhuyingyewu = zhuyingyewu;
        this.jinchukou = jinchukou;
    }

    public Gsinfo() {
    }

    public String getGongsi() {
        return gongsi;
    }

    public void setGongsi(String gongsi) {
        this.gongsi = gongsi;
    }

    public String getLianxiren() {
        return lianxiren;
    }

    public void setLianxiren(String lianxiren) {
        this.lianxiren = lianxiren;
    }

    public String getXingbie() {
        return xingbie;
    }

    public void setXingbie(String xingbie) {
        this.xingbie = xingbie;
    }

    public String getZhiwei() {
        return zhiwei;
    }

    public void setZhiwei(String zhiwei) {
        this.zhiwei = zhiwei;
    }

    public String getShengfen() {
        return shengfen;
    }

    public void setShengfen(String shengfen) {
        this.shengfen = shengfen;
    }

    public String getChengshi() {
        return chengshi;
    }

    public void setChengshi(String chengshi) {
        this.chengshi = chengshi;
    }

    public String getGongsidizhi() {
        return gongsidizhi;
    }

    public void setGongsidizhi(String gongsidizhi) {
        this.gongsidizhi = gongsidizhi;
    }

    public String getYoubian() {
        return youbian;
    }

    public void setYoubian(String youbian) {
        this.youbian = youbian;
    }

    public String getGudingdianhua() {
        return gudingdianhua;
    }

    public void setGudingdianhua(String gudingdianhua) {
        this.gudingdianhua = gudingdianhua;
    }

    public String getChuanzhen() {
        return chuanzhen;
    }

    public void setChuanzhen(String chuanzhen) {
        this.chuanzhen = chuanzhen;
    }

    public String getQq() {
        return qq;
    }

    public void setQq(String qq) {
        this.qq = qq;
    }

    public String getMsn() {
        return msn;
    }

    public void setMsn(String msn) {
        this.msn = msn;
    }

    public String getSuoshutype() {
        return suoshutype;
    }

    public void setSuoshutype(String suoshutype) {
        this.suoshutype = suoshutype;
    }

    public String getHangyedalei() {
        return hangyedalei;
    }

    public void setHangyedalei(String hangyedalei) {
        this.hangyedalei = hangyedalei;
    }

    public String getQiyexingzhi() {
        return qiyexingzhi;
    }

    public void setQiyexingzhi(String qiyexingzhi) {
        this.qiyexingzhi = qiyexingzhi;
    }

    public String getJingyingmoshi() {
        return jingyingmoshi;
    }

    public void setJingyingmoshi(String jingyingmoshi) {
        this.jingyingmoshi = jingyingmoshi;
    }

    public String getMoney() {
        return money;
    }

    public void setMoney(String money) {
        this.money = money;
    }

    public String getNianmoney() {
        return nianmoney;
    }

    public void setNianmoney(String nianmoney) {
        this.nianmoney = nianmoney;
    }

    public String getGuyuan() {
        return guyuan;
    }

    public void setGuyuan(String guyuan) {
        this.guyuan = guyuan;
    }

    public String getZhuyingyewu() {
        return zhuyingyewu;
    }

    public void setZhuyingyewu(String zhuyingyewu) {
        this.zhuyingyewu = zhuyingyewu;
    }

    public String getJinchukou() {
        return jinchukou;
    }

    public void setJinchukou(String jinchukou) {
        this.jinchukou = jinchukou;
    }
}
