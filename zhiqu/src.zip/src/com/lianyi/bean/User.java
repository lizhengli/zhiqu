package com.lianyi.bean;

import java.sql.Timestamp;

/**
 * Created by Lenovo on 2017/6/16.
 */
public class User {
    private int id;
    private String name;
    private String password;
    private String swemail;
    private String aqemail;
    private String phonenumber;
    private Timestamp ctime;

    public String getPassword() {
        return password;
    }

    public User() {
    }

    public User(int id, String name, String password, String aqemail, String swemail, String phonenumber, Timestamp ctime) {
        this.id = id;
        this.name = name;
        this.password = password;
        this.aqemail = aqemail;
        this.swemail = swemail;
        this.phonenumber = phonenumber;
        this.ctime = ctime;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getSwemail() {
        return swemail;
    }

    public void setSwemail(String swemail) {
        this.swemail = swemail;
    }

    public String getAqemail() {
        return aqemail;
    }

    public void setAqemail(String aqemail) {
        this.aqemail = aqemail;
    }

    public String getPhonenumber() {
        return phonenumber;
    }

    public void setPhonenumber(String phonenumber) {
        this.phonenumber = phonenumber;
    }

    public Timestamp getCtime() {
        return ctime;
    }

    public void setCtime(Timestamp ctime) {
        this.ctime = ctime;
    }

    public User(int id, String name) {
        this.id = id;
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "User{" +
                "id=" + id +
                ", name='" + name + '\'' +
                '}';
    }
}
