package com.lianyi.bean;

import java.sql.Timestamp;

/**
 * Created by dell on 2017/7/5.
 */
public class FabuRen {
    private Timestamp ftime;
    private String title;
    private String content;
    private String address;
    private String lxr;
    private String gsname;
    private String swemail;
    private String phonenumber;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public FabuRen(Timestamp ftime,String title,String content, String address, String lxr, String gsname, String swemail, String phonenumber) {
        this.ftime = ftime;
        this.title = title;
        this.content=content;
        this.address = address;
        this.lxr = lxr;
        this.gsname = gsname;
        this.swemail = swemail;
        this.phonenumber = phonenumber;
    }

    public FabuRen() {
    }

    public Timestamp getFtime() {
        return ftime;
    }

    public void setFtime(Timestamp ftime) {
        this.ftime = ftime;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getLxr() {
        return lxr;
    }

    public void setLxr(String lxr) {
        this.lxr = lxr;
    }

    public String getGsname() {
        return gsname;
    }

    public void setGsname(String gsname) {
        this.gsname = gsname;
    }

    public String getSwemail() {
        return swemail;
    }

    public void setSwemail(String swemail) {
        this.swemail = swemail;
    }

    public String getPhonenumber() {
        return phonenumber;
    }

    public void setPhonenumber(String phonenumber) {
        this.phonenumber = phonenumber;
    }

    @Override
    public String toString() {
        return "FabuRen{" +
                "ftime=" + ftime +
                ", title='" + title + '\'' +
                ", content='" + content + '\'' +
                ", address='" + address + '\'' +
                ", lxr='" + lxr + '\'' +
                ", gsname='" + gsname + '\'' +
                ", swemail='" + swemail + '\'' +
                ", phonenumber='" + phonenumber + '\'' +
                '}';
    }
}
