package com.lianyi.bean;

import javax.xml.soap.Text;
import java.sql.Timestamp;

/**
 * Created by dell on 2017/7/4.
 */
public class xinwen {
    private int id;
    private String type;
    private String title;
    private String nerirong;
    private Timestamp ctime;
    private int status;
    private int uid;

}
