package com.lianyi.bean;

/**
 * Created by dell on 2017/7/19.
 */
public class Number {
    private int count;

    public Number(int count) {
        this.count = count;
    }

    public Number() {
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

}
