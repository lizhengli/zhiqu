package com.lianyi.bean;

/**
 * Created by dell on 2017/7/8.
 */
public class ZtreeData {
    private String name;
    private Boolean checked;
    private int id;
    private Boolean open = true;
    private int pId;
    public ZtreeData() {

    }

    public ZtreeData(String name, Boolean checked, int id, Boolean open,int pId) {
        this.name = name;
        this.checked = checked;
        this.id = id;
        this.open = open;
        this.pId = pId;

    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Boolean getChecked() {
        return checked;
    }

    public void setChecked(Boolean checked) {
        this.checked = checked;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Boolean getOpen() {
        return open;
    }

    public void setOpen(Boolean open) {
        this.open = open;
    }

    public int getPId() {

        return pId;
    }

    public void setPId(int pId) {
        this.pId = pId;
    }
}
