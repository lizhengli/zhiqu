package com.lianyi.bean;


/**
 * Created by dell on 2017/7/12.
 */
public class Rizhi {
    private int id;
    private String caozuo;
    private String user;
    private String ctime;
    private String url;
    private String qtype;
    private String uip;
    private String biaozhi;

    public Rizhi(int id, String caozuo, String user, String ctime, String url, String qtype, String uip, String biaozhi) {
        this.id = id;
        this.caozuo = caozuo;
        this.user = user;
        this.ctime = ctime;
        this.url = url;
        this.qtype = qtype;
        this.uip = uip;
        this.biaozhi = biaozhi;
    }

    public Rizhi(String caozuo, String user, String ctime, String url, String uip, String biaozhi) {
        this.caozuo = caozuo;
        this.user = user;
        this.ctime = ctime;
        this.url = url;
        this.uip = uip;
        this.biaozhi = biaozhi;
    }

    public Rizhi(String caozuo, String user, String ctime, String url, String qtype, String uip, String biaozhi) {
        this.caozuo = caozuo;
        this.user = user;
        this.ctime = ctime;
        this.url = url;
        this.qtype = qtype;
        this.uip = uip;
        this.biaozhi = biaozhi;
    }

    public String getUip() {
        return uip;
    }

    public void setUip(String uip) {
        this.uip = uip;
    }

    public String getBiaozhi() {
        return biaozhi;
    }

    public void setBiaozhi(String biaozhi) {
        this.biaozhi = biaozhi;
    }

    public Rizhi() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCaozuo() {
        return caozuo;
    }

    public void setCaozuo(String caozuo) {
        this.caozuo = caozuo;
    }

    public String getCtime() {
        return ctime;
    }

    public void setCtime(String ctime) {
        this.ctime = ctime;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getQtype() {
        return qtype;
    }

    public void setQtype(String qtype) {
        this.qtype = qtype;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
