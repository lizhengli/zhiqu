package com.lianyi.bean;

/**
 * Created by dell on 2017/6/30.
 */
public class ZhiQuUser {
    private String  name;
    private String password;
    private String shangwu;
    private String anquan;
    private String shouji;

    public ZhiQuUser() {
    }

    public ZhiQuUser(String name, String password) {
        this.name = name;
        this.password = password;
    }

    public ZhiQuUser(String name, String password, String shangwu, String anquan, String shouji) {
        this.name = name;
        this.password = password;
        this.shangwu = shangwu;
        this.anquan = anquan;
        this.shouji = shouji;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getshangwu() {
        return shangwu;
    }

    public void setshangwu(String shangwu) {
        this.shangwu = shangwu;
    }

    public String getAnquan() {
        return anquan;
    }

    public void setAnquan(String anquan) {
        this.anquan = anquan;
    }

    public String getShouji() {
        return shouji;
    }

    public void setShouji(String shouji) {
        this.shouji = shouji;
    }
}
















