package com.lianyi.bean;

/**
 * Created by dell on 2017/6/28.
 */
public class Message {
    public int status;
    public String message;
}
