package com.lianyi.bean;

import java.sql.Timestamp;

/**
 * Created by dell on 2017/6/28.
 */
public class AdminUser {
    private int id;
    private String name;
    private String password;
    private Timestamp ctime;
    private String loginip;
    private int status;

    public AdminUser() {

    }

    public AdminUser(String name, String password) {
        this.name = name;
        this.password = password;
    }

    public AdminUser(int id, String name, String password, Timestamp ctime, String loginip, int status) {
        this.id = id;
        this.name = name;
        this.password = password;
        this.ctime = ctime;
        this.loginip = loginip;
        this.status = status;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Timestamp getCtime() {
        return ctime;
    }

    public void setCtime(Timestamp ctime) {
        this.ctime = ctime;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLoginip() {
        return loginip;
    }

    public void setLoginip(String loginip) {
        this.loginip = loginip;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }
}
