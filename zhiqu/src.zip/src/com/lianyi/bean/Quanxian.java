package com.lianyi.bean;

import java.sql.Timestamp;

/**
 * Created by dell on 2017/7/6.
 */
public class Quanxian {
    private int id;
    private String title;
    private String q_type;
    private String url;
    private Timestamp ctime;
    private int pId;
    private int status;

    public int getpId() {
        return pId;
    }

    public void setpId(int pId) {
        this.pId = pId;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getQ_type() {
        return q_type;
    }

    public void setQ_type(String q_type) {
        this.q_type = q_type;
    }

    public Quanxian(int id, String title, String q_type, String url, Timestamp ctime,int pId,int status) {
        this.id = id;
        this.title = title;
        this.q_type = q_type;
        this.url = url;
        this.ctime = ctime;
        this.pId = pId;
        this.status = status;
    }

    public Quanxian(int id,String title, String q_type, String url, int status) {
        this.id = id;
        this.title = title;
        this.q_type = q_type;
        this.url = url;
        this.status = status;
    }

    public Quanxian(int id, String title, String url, Timestamp ctime) {
        this.id = id;
        this.title = title;
        this.url = url;
        this.ctime = ctime;
    }

    public Quanxian(int id, String title, String url) {
        this.id = id;
        this.title = title;
        this.url = url;
    }

    public Quanxian() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public Timestamp getCtime() {
        return ctime;
    }

    public void setCtime(Timestamp ctime) {
        this.ctime = ctime;
    }
}
