package com.lianyi.bean;

/**
 * Created by dell on 2017/7/16.
 */
public class InfoType {
    private int id;
    private String name;
    private int pid;

    public InfoType(int id, String name, int pid) {
        this.id = id;
        this.name = name;
        this.pid = pid;
    }

    public InfoType() {

    }

    public int getId() {
        return id;
    }

    @Override
    public String toString() {
        return "InfoType{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", pid=" + pid +
                '}';
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getPid() {
        return pid;
    }

    public void setPid(int pid) {
        this.pid = pid;
    }
}
