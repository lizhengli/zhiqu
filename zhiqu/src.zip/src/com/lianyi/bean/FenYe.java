package com.lianyi.bean;

/**
 * Created by dell on 2017/7/19.
 */
public class FenYe {
    private int page;
    private int shownumber;
    String ku;

    public FenYe(int page, int shownumber, String ku) {
        this.page = page;
        this.shownumber = shownumber;
        this.ku = ku;
    }

    public FenYe() {
    }

    public int getPage() {
        return page;
    }

    public void setPage(int page) {
        this.page = page;
    }

    public int getShownumber() {
        return shownumber;
    }

    public void setShownumber(int shownumber) {
        this.shownumber = shownumber;
    }

    public String getKu() {
        return ku;
    }

    public void setKu(String ku) {
        this.ku = ku;
    }

    @Override
    public String toString() {
        return "FenYe{" +
                "page=" + page +
                ", shownumber=" + shownumber +
                ", ku='" + ku + '\'' +
                '}';
    }
}
