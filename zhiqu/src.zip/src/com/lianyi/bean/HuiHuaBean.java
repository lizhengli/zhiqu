package com.lianyi.bean;

/**
 * Created by Lenovo on 2017/7/17.
 */
public class HuiHuaBean {
    private int id;//编号
    private String name;//备注
    private String ip;//用户IP
    private String sessionID;//用户标识
    private String date;//访问时间

    public HuiHuaBean() {
    }

    public HuiHuaBean(int id, String name, String ip, String sessionID, String date) {
        this.id = id;
        this.name = name;
        this.ip = ip;
        this.sessionID = sessionID;
        this.date = date;
    }

    @Override
    public String toString() {
        return "HuiHuaBean{" + "id=" + id + ", name='" + name + '\'' + ", ip='" + ip + '\'' + ", sessionID='" + sessionID + '\'' + ", date=" + date + '}';
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public String getSessionID() {
        return sessionID;
    }

    public void setSessionID(String sessionID) {
        this.sessionID = sessionID;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}
