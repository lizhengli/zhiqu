package com.lianyi.bean;

import java.sql.Timestamp;

/**
 * Created by dell on 2017/7/5.
 */
public class info {
    private int id;
    private String title;
    private String desc;
    private String content;
    private Timestamp ctime;
    private int uid;
    private int sontype;
    private int ftype;
    private int status;
    private int gqid;
    private int pageCount;

    public info(int id, String title, String desc, String content, Timestamp ctime, int uid,int sontype,int ftype,int status,int gqid) {
        this.id = id;
        this.title = title;
        this.desc = desc;
        this.content = content;
        this.ctime = ctime;
        this.uid = uid;
        this.sontype=sontype;
        this.ftype=ftype;
        this.status = status;
        this.gqid=gqid;

    }

    public info(int gqid, int status, int id, String title, int uid) {
        this.gqid = gqid;
        this.status = status;
        this.id = id;
        this.title = title;
        this.uid = uid;
    }

    public info() {
    }
    public info(int pagecount,int id,String title, String desc, String content,Timestamp ctime,int uid,int sontype,int ftype,int status) {
        this.pageCount=pagecount;
        this.id=id;
        this.title=title;
        this.desc=desc;
        this.content=content;
        this.ctime=ctime;
        this.uid=uid;
        this.sontype=sontype;
        this.ftype=ftype;
        this.status=status;
    }
    public info(int id,String title, String desc, String content,Timestamp ctime,int uid,int sontype,int ftype,int status) {
        this.id=id;
        this.title=title;
        this.desc=desc;
        this.content=content;
        this.ctime=ctime;
        this.uid=uid;
        this.sontype=sontype;
        this.ftype=ftype;
        this.status=status;
    }
    public info(String title, String desc, String content, int uid,int sontype,int ftype,int gqid) {
        this.title = title;
        this.desc = desc;
        this.content = content;
        this.uid = uid;
        this.sontype=sontype;
        this.ftype=ftype;
        this.gqid=gqid;
    }

    @Override
    public String toString() {
        return "info{" +
                "title='" + title + '\'' +
                ", uid=" + uid +
                ", status=" + status +
                ", gqid=" + gqid +
                ", id=" + id +
                '}';
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public Timestamp getCtime() {
        return ctime;
    }

    public void setCtime(Timestamp ctime) {
        this.ctime = ctime;
    }

    public int getUid() {
        return uid;
    }

    public void setUid(int uid) {
        this.uid = uid;
    }

    public int getSontype() {
        return sontype;
    }

    public void setSontype(int sontype) {
        this.sontype = sontype;
    }

    public int getFtype() {
        return ftype;
    }

    public void setFtype(int ftype) {
        this.ftype = ftype;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public int getGqid() {
        return gqid;
    }

    public void setGqid(int gqid) {
        this.gqid = gqid;
    }

    public int getPageCount() {
        return pageCount;
    }

    public void setPageCount(int pageCount) {
        this.pageCount = pageCount;
    }
}
