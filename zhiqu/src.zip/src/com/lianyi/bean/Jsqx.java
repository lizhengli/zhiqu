package com.lianyi.bean;

/**
 * Created by dell on 2017/7/10.
 */
public class Jsqx {
    private int roleid;
    private int perid;

    public Jsqx(int roleid, int perid) {
        this.roleid = roleid;
        this.perid = perid;

    }

    public Jsqx(int perid) {
        this.perid = perid;
    }

    public Jsqx() {
    }

    public int getRoleid() {
        return roleid;
    }

    public void setRoleid(int roleid) {
        this.roleid = roleid;
    }

    public int getPerid() {
        return perid;
    }

    public void setPerid(int perid) {
        this.perid = perid;
    }
}
