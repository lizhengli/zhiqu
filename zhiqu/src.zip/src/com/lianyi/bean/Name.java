package com.lianyi.bean;

/**
 * Created by dell on 2017/7/3.
 */
public class Name {
    private String name;
    private String password;

    public Name() {
    }

    public Name(String name, String password) {
        this.name = name;
        this.password = password;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
