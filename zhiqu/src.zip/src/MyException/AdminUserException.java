package MyException;

/**
 * Created by dell on 2017/6/28.
 */
public class AdminUserException extends Exception {
    public AdminUserException(String message){
        super(message);
    }
}
