package MyException;

/**
 * Created by dell on 2017/6/28.
 */
public class AdminUserPasswordException extends Exception {
    public AdminUserPasswordException(String message){
        super(message);
    }
}
